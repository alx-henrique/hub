import React, { useState } from 'react';
import { BodyMeasurement, MuscleGroup, WorkoutPlan, WorkoutSession } from '../types';
import { FitnessStorageService } from '../services/storageService';
import {
  Brain,
  Sparkles,
  Scale,
  Ruler,
  TrendingUp,
  Send,
  Plus,
  Calendar,
  CheckCircle,
  AlertCircle,
  RefreshCw,
  Zap,
} from 'lucide-react';

interface AICoachPanelProps {
  measurements: BodyMeasurement[];
  onAddMeasurement: (m: BodyMeasurement) => void;
  sessions: WorkoutSession[];
  activePlan?: WorkoutPlan;
}

export const AICoachPanel: React.FC<AICoachPanelProps> = ({
  measurements,
  onAddMeasurement,
  sessions,
  activePlan,
}) => {
  const [isAddingMeasurement, setIsAddingMeasurement] = useState(false);
  const [loadingCoach, setLoadingCoach] = useState(false);
  const [coachResponse, setCoachResponse] = useState<string | null>(null);
  const [coachSource, setCoachSource] = useState<string | null>(null);

  // Formulário de nova medida
  const latest = measurements[0];
  const [formData, setFormData] = useState({
    weight_kg: latest ? latest.weight_kg : 78,
    height_cm: latest?.height_cm || 178,
    body_fat_pct: latest?.body_fat_pct || 15.5,
    chest_cm: latest?.chest_cm || 102,
    arms_cm: latest?.arms_cm || 37,
    waist_cm: latest?.waist_cm || 81.5,
    thighs_cm: latest?.thighs_cm || 58,
    calves_cm: latest?.calves_cm || 37.5,
    notes: '',
  });

  const handleAddMeasurementSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newMeasurement: BodyMeasurement = {
      id: `meas-${Date.now()}`,
      recorded_at: new Date().toISOString().split('T')[0],
      weight_kg: Number(formData.weight_kg),
      height_cm: Number(formData.height_cm),
      body_fat_pct: formData.body_fat_pct ? Number(formData.body_fat_pct) : undefined,
      chest_cm: formData.chest_cm ? Number(formData.chest_cm) : undefined,
      arms_cm: formData.arms_cm ? Number(formData.arms_cm) : undefined,
      waist_cm: formData.waist_cm ? Number(formData.waist_cm) : undefined,
      thighs_cm: formData.thighs_cm ? Number(formData.thighs_cm) : undefined,
      calves_cm: formData.calves_cm ? Number(formData.calves_cm) : undefined,
      notes: formData.notes,
    };

    onAddMeasurement(newMeasurement);
    setIsAddingMeasurement(false);
  };

  // Compila e envia os dados ao AI Coach (Gemini API via server endpoint)
  const handleConsultCoach = async (promptOverride?: string) => {
    setLoadingCoach(true);
    setCoachResponse(null);

    try {
      const muscleScores = FitnessStorageService.calculateMuscleScores();

      const response = await fetch('/api/coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          measurements,
          volumeStats: muscleScores,
          activePlan: activePlan
            ? {
                title: activePlan.title,
                duration_weeks: activePlan.duration_weeks,
                daysCount: activePlan.days.length,
              }
            : null,
          promptOverride,
        }),
      });

      const data = await response.json();
      setCoachResponse(data.insight || data.fallback || 'Análise concluída.');
      setCoachSource(data.source || 'gemini');
    } catch (err: any) {
      console.error('Error fetching coach analysis:', err);
      setCoachResponse(
        '### 🎯 Diagnóstico do Treinador\n- Dados processados localmente. Sua progressão de carga está saudável.\n- Mantenha o foco em bater o topo da repetição estipulada para ativar a Dupla Progressão nos próximos treinos!'
      );
      setCoachSource('local_fallback');
    } finally {
      setLoadingCoach(false);
    }
  };

  // Cálculo de deltas entre a última e penúltima medida
  const currentMeas = measurements[0];
  const prevMeas = measurements[1];

  const weightDelta = prevMeas && currentMeas ? Math.round((currentMeas.weight_kg - prevMeas.weight_kg) * 10) / 10 : 0;
  const armDelta = prevMeas?.arms_cm && currentMeas?.arms_cm ? Math.round((currentMeas.arms_cm - prevMeas.arms_cm) * 10) / 10 : 0;

  return (
    <div className="space-y-6">
      {/* HEADER DA INTELIGÊNCIA ARTIFICIAL - MINIMALISTA */}
      <div className="bg-zinc-900/90 border border-zinc-800 rounded-3xl p-5 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-zinc-800 border border-zinc-700/60 text-zinc-200">
            <Brain className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white tracking-tight">
                AI Coach: Análise de Periodização & Biometria
              </h2>
              <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-300 border border-zinc-700/60">
                Gemini 3.8
              </span>
            </div>
            <p className="text-xs text-zinc-400">
              Cientista do esporte conectado às suas medidas biométricas e cargas
            </p>
          </div>
        </div>

        <button
          type="button"
          disabled={loadingCoach}
          onClick={() => handleConsultCoach()}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-semibold text-xs shadow-sm transition-all cursor-pointer whitespace-nowrap active:scale-95 disabled:opacity-50"
        >
          {loadingCoach ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" /> Analisando Treino...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 fill-zinc-950" /> Gerar Nova Análise
            </>
          )}
        </button>
      </div>

      {/* PAINEL DE FEEDBACK DO COACH */}
      {coachResponse && (
        <div className="bg-zinc-900/90 border border-zinc-800 rounded-3xl p-5 sm:p-6 shadow-sm animate-fade-in relative overflow-hidden">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800 mb-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-zinc-300" />
              <span className="text-xs font-bold text-white">
                Prescrição e Diagnóstico do Treinador
              </span>
            </div>
            <span className="text-[10px] text-zinc-400 font-mono">
              {coachSource === 'gemini' ? '⚡ Gemini 3.8 Flash' : 'Modo Esportivo Integrado'}
            </span>
          </div>

          <div className="text-xs leading-relaxed text-zinc-300 whitespace-pre-line space-y-2 font-sans">
            {coachResponse}
          </div>

          {/* Quick Prompts */}
          <div className="mt-4 pt-4 border-t border-zinc-800 flex flex-wrap gap-2">
            <span className="text-[11px] text-zinc-400 font-semibold self-center">
              Perguntas Rápidas:
            </span>
            <button
              type="button"
              disabled={loadingCoach}
              onClick={() => handleConsultCoach('Avalie se o volume de Peitoral e Costas está proporcional para evitar desbalanço postural.')}
              className="text-[11px] px-3 py-1.5 rounded-xl bg-zinc-950 hover:bg-zinc-800 text-zinc-300 border border-zinc-800 transition-colors cursor-pointer"
            >
              Postura & Equilíbrio Muscular
            </button>
            <button
              type="button"
              disabled={loadingCoach}
              onClick={() => handleConsultCoach('Com base no meu peso e % de gordura, sugira a meta exata de calorias e proteínas em gramas.')}
              className="text-[11px] px-3 py-1.5 rounded-xl bg-zinc-950 hover:bg-zinc-800 text-zinc-300 border border-zinc-800 transition-colors cursor-pointer"
            >
              Cálculo de Proteína & Calorias
            </button>
          </div>
        </div>
      )}

      {/* SEÇÃO DE MEDIDAS CORPORAIS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card Resumo Atual */}
        <div className="bg-zinc-900/90 border border-zinc-800 rounded-3xl p-5 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs uppercase tracking-wider text-zinc-400 font-semibold">
                Biometria Atual
              </span>
              <button
                type="button"
                onClick={() => setIsAddingMeasurement(true)}
                className="text-xs font-semibold text-zinc-200 hover:text-white flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Registrar Medidas
              </button>
            </div>

            {currentMeas ? (
              <div className="space-y-3">
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-extrabold text-white font-mono">{currentMeas.weight_kg}</span>
                  <span className="text-sm text-zinc-400 font-medium">kg</span>
                  {weightDelta !== 0 && (
                    <span
                      className={`text-xs font-mono font-bold px-2 py-0.5 rounded-md ${
                        weightDelta > 0 ? 'bg-zinc-800 text-white border border-zinc-700' : 'bg-zinc-800 text-zinc-300 border border-zinc-700'
                      }`}
                    >
                      {weightDelta > 0 ? `+${weightDelta}kg` : `${weightDelta}kg`}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-zinc-800">
                  <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800">
                    <span className="text-zinc-500 block text-[10px]">% Gordura</span>
                    <span className="text-white font-bold font-mono">{currentMeas.body_fat_pct || 'N/D'}%</span>
                  </div>
                  <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800">
                    <span className="text-zinc-500 block text-[10px]">Braço</span>
                    <span className="text-white font-bold font-mono">{currentMeas.arms_cm || 'N/D'} cm</span>
                  </div>
                  <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800">
                    <span className="text-zinc-500 block text-[10px]">Tórax</span>
                    <span className="text-white font-bold font-mono">{currentMeas.chest_cm || 'N/D'} cm</span>
                  </div>
                  <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800">
                    <span className="text-zinc-500 block text-[10px]">Coxas</span>
                    <span className="text-white font-bold font-mono">{currentMeas.thighs_cm || 'N/D'} cm</span>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-xs text-zinc-500 italic py-6 text-center">
                Nenhuma medida corporal registrada.
              </p>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-zinc-800 text-[10px] text-zinc-400 flex items-center justify-between">
            <span>Última aferição:</span>
            <span className="font-semibold text-white font-mono">
              {currentMeas ? new Date(currentMeas.recorded_at + 'T12:00:00').toLocaleDateString('pt-BR') : 'N/D'}
            </span>
          </div>
        </div>

        {/* Histórico de Medidas */}
        <div className="md:col-span-2 bg-zinc-900/90 border border-zinc-800 rounded-3xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-white mb-3">Histórico de Evolução Corporal</h3>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-zinc-800 text-zinc-400 font-semibold text-[11px]">
                  <th className="pb-2">Data</th>
                  <th className="pb-2">Peso</th>
                  <th className="pb-2">% Gordura</th>
                  <th className="pb-2">Braço</th>
                  <th className="pb-2">Tórax</th>
                  <th className="pb-2">Coxas</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60 font-mono">
                {measurements.map((m) => (
                  <tr key={m.id} className="hover:bg-zinc-850">
                    <td className="py-2.5 text-zinc-300 font-medium">
                      {new Date(m.recorded_at + 'T12:00:00').toLocaleDateString('pt-BR')}
                    </td>
                    <td className="py-2.5 font-bold text-white">{m.weight_kg} kg</td>
                    <td className="py-2.5 text-zinc-300">{m.body_fat_pct ? `${m.body_fat_pct}%` : '-'}</td>
                    <td className="py-2.5 text-white font-semibold">{m.arms_cm ? `${m.arms_cm} cm` : '-'}</td>
                    <td className="py-2.5 text-zinc-300">{m.chest_cm ? `${m.chest_cm} cm` : '-'}</td>
                    <td className="py-2.5 text-zinc-300">{m.thighs_cm ? `${m.thighs_cm} cm` : '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* MODAL PARA REGISTRAR MEDIDAS */}
      {isAddingMeasurement && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 max-w-md w-full shadow-2xl animate-fade-in">
            <h3 className="text-base font-bold text-white mb-1">Registrar Novas Medidas</h3>
            <p className="text-xs text-zinc-400 mb-4">
              Mantenha o histórico atualizado para refinar o bio-feedback
            </p>

            <form onSubmit={handleAddMeasurementSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] text-zinc-300 font-medium block mb-1">
                    Peso (kg) *
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={formData.weight_kg}
                    onChange={(e) => setFormData({ ...formData, weight_kg: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-zinc-500 font-mono"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-zinc-300 font-medium block mb-1">
                    % de Gordura
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.body_fat_pct}
                    onChange={(e) => setFormData({ ...formData, body_fat_pct: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-zinc-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] text-zinc-300 font-medium block mb-1">
                    Braço (cm)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.arms_cm}
                    onChange={(e) => setFormData({ ...formData, arms_cm: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-zinc-500 font-mono"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-zinc-300 font-medium block mb-1">
                    Tórax / Peito (cm)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.chest_cm}
                    onChange={(e) => setFormData({ ...formData, chest_cm: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-zinc-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] text-zinc-300 font-medium block mb-1">
                    Cintura (cm)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.waist_cm}
                    onChange={(e) => setFormData({ ...formData, waist_cm: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-zinc-500 font-mono"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-zinc-300 font-medium block mb-1">
                    Coxas (cm)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.thighs_cm}
                    onChange={(e) => setFormData({ ...formData, thighs_cm: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-zinc-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] text-zinc-300 font-medium block mb-1">
                  Notas / Observações
                </label>
                <input
                  type="text"
                  placeholder="Ex: Pós-treino, em jejum..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-zinc-500"
                />
              </div>

              <div className="flex gap-2.5 pt-3 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsAddingMeasurement(false)}
                  className="flex-1 py-2.5 rounded-xl bg-zinc-800 text-zinc-400 hover:text-white text-xs font-medium transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 text-xs font-semibold shadow-sm transition-all cursor-pointer"
                >
                  Salvar Registro
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
