import { Exercise } from '../types';

export const EXERCISE_DATABASE: Exercise[] = [
  // =========================================================================
  // 1. LEVANTAMENTO TERRA & CADEIA POSTERIOR (DEADLIFT & POSTERIOR CHAIN)
  // =========================================================================
  {
    id: 'ex-deadlift-conventional',
    name: 'Levantamento Terra Convencional (Deadlift com Barra Olímpica)',
    target_muscle: 'back',
    secondary_muscles: ['hamstrings', 'glutes', 'forearms', 'core'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Barra encostada nas canelas, pés na largura do quadril com pegada firme pronada ou invertida.',
      'Mantenha a coluna rigorosamente neutra, peito estufado e dorsais travadas (travar axilas).',
      'Empurre o chão através dos calcanhares, estendendo quadril e joelhos em movimento contínuo.',
      'Trave o quadril no topo contraindo glúteos sem hiperextender a lombar.',
    ],
  },
  {
    id: 'ex-deadlift-sumo',
    name: 'Levantamento Terra Sumô (Sumo Deadlift com Barra)',
    target_muscle: 'glutes',
    secondary_muscles: ['quadriceps', 'hamstrings', 'back', 'core'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Base bem aberta com pontas dos pés viradas a 45° em direção às anilhas.',
      'Pegada estreita por dentro dos joelhos com tronco mais vertical.',
      'Ativação extrema de glúteos e adutores com menor estresse de cisalhamento na lombar.',
    ],
  },
  {
    id: 'ex-deadlift-romanian-barbell',
    name: 'Levantamento Terra Romeno (RDL com Barra)',
    target_muscle: 'hamstrings',
    secondary_muscles: ['glutes', 'back', 'forearms'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Inicie em pé com a barra travada nas coxas. Joelhos em leve microflexão constante.',
      'Projete o quadril para trás até a barra passar levemente dos joelhos sentindo tensão máxima nos posteriores.',
      'Suba empurrando o quadril para frente contraindo os glúteos.',
    ],
  },
  {
    id: 'ex-deadlift-romanian-dumbbell',
    name: 'Levantamento Terra Romeno com Halteres (Dumbbell RDL)',
    target_muscle: 'hamstrings',
    secondary_muscles: ['glutes', 'back', 'forearms'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Segure halteres pesados rentes às coxas com pegada neutra ou pronada.',
      'Jogue os ísquios para trás mantendo as escápulas aduzidas.',
      'Excelente liberdade de punho e equilíbrio para focar no alongamento dos ísquiotibiais.',
    ],
  },
  {
    id: 'ex-deadlift-trap-bar',
    name: 'Levantamento Terra com Trap Bar (Hex Bar Deadlift)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['back', 'glutes', 'hamstrings', 'forearms'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Posicione-se no centro da barra hexagonal segurando nas manoplas neutras.',
      'Distribuição perfeita de forças entre quadríceps, eretores e glúteos.',
      'Permite erguer cargas recordes com padrão biomecânico altamente seguro para a coluna.',
    ],
  },
  {
    id: 'ex-deadlift-rack-pull',
    name: 'Levantamento Terra no Bloco / Rack Pull (Gaiola ou Smith)',
    target_muscle: 'back',
    secondary_muscles: ['glutes', 'forearms', 'core'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Inicie com a barra apoiada nos suportes de segurança na altura logo abaixo dos joelhos.',
      'Movimento focado na extensão final do quadril e espessura do trapézio e eretores da espinha.',
      'Permite sobrecarga supramáxima de carga para desenvolver densidade nas costas.',
    ],
  },
  {
    id: 'ex-deadlift-deficit',
    name: 'Levantamento Terra com Déficit (Sobre Plataforma/Anilha)',
    target_muscle: 'back',
    secondary_muscles: ['hamstrings', 'glutes', 'forearms'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Posicione os pés sobre uma plataforma ou anilha de 5 a 10 cm.',
      'Aumenta a amplitude de movimento e desenvolve a potência de arrancada do solo.',
    ],
  },
  {
    id: 'ex-deadlift-single-leg',
    name: 'Levantamento Terra Unilateral com Halter (Single-Leg RDL)',
    target_muscle: 'hamstrings',
    secondary_muscles: ['glutes', 'core'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Apoie-se em uma perna enquanto a outra estende para trás em linha com o tronco.',
      'Desça o halter rente à canela da perna de apoio com estabilização proprioceptiva.',
    ],
  },
  {
    id: 'ex-deadlift-snatch-grip',
    name: 'Levantamento Terra com Pegada Aberta (Snatch-Grip Deadlift)',
    target_muscle: 'back',
    secondary_muscles: ['hamstrings', 'glutes', 'forearms'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Segure na barra com pegada bem afastada próxima aos colares das anilhas.',
      'Aumenta brutalmente o percurso do movimento e a ativação dos trapézios e romboides.',
    ],
  },
  {
    id: 'ex-stiff-barbell',
    name: 'Stiff com Barra (Barbell Stiff-Leg Deadlift)',
    target_muscle: 'hamstrings',
    secondary_muscles: ['glutes', 'back'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Joelhos quase totalmente estendidos (com mínima folga articular protetora).',
      'Desça a barra rente às canelas focando 100% no estiramento dos ísquios.',
    ],
  },
  {
    id: 'ex-stiff-dumbbell',
    name: 'Stiff com Halteres (Dumbbell Stiff)',
    target_muscle: 'hamstrings',
    secondary_muscles: ['glutes', 'back'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pés na largura do quadril, descendo os halteres rente aos membros inferiores.',
      'Contraia os glúteos no topo da extensão do quadril.',
    ],
  },
  {
    id: 'ex-good-morning',
    name: 'Bom Dia com Barra (Barbell Good Morning)',
    target_muscle: 'hamstrings',
    secondary_muscles: ['glutes', 'back'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Barra apoiada nos trapézios como no agachamento.',
      'Flexione o quadril para trás mantendo as costas eretas até o tronco ficar quase paralelo ao chão.',
    ],
  },

  // =========================================================================
  // 2. PEITORAL (CHEST)
  // =========================================================================
  {
    id: 'ex-bench-press',
    name: 'Supino Reto com Barra Olímpica',
    target_muscle: 'chest',
    secondary_muscles: ['triceps', 'shoulders'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Deite no banco reto, pés plantados no chão gerando leg drive, escápulas aduzidas.',
      'Desça a barra controladamente até o terço inferior do esterno.',
      'Empurre estendendo os cotovelos sem descolar os ombros do banco.',
    ],
  },
  {
    id: 'ex-dumbbell-bench-press',
    name: 'Supino Reto com Halteres',
    target_muscle: 'chest',
    secondary_muscles: ['triceps', 'shoulders'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Halteres na linha dos mamilos com cotovelos em ângulo de ~60° em relação ao tronco.',
      'Empurre para cima convergindo ligeiramente sem bater os halteres no topo.',
    ],
  },
  {
    id: 'ex-incline-barbell-press',
    name: 'Supino Inclinado com Barra (30° a 45°)',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders', 'triceps'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Banco inclinado a ~30°-45°. Desça a barra até a clavícula/peitoral superior.',
      'Foco prioritário na porção clavicular do peitoral maior.',
    ],
  },
  {
    id: 'ex-incline-dumbbell-press',
    name: 'Supino Inclinado com Halteres',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders', 'triceps'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Amplitude total descendo os halteres abaixo do nível do queixo para alongar o peitoral superior.',
      'Suba com cadência controlada mantendo o peito inflado.',
    ],
  },
  {
    id: 'ex-decline-bench-press',
    name: 'Supino Declinado com Barra ou Halteres',
    target_muscle: 'chest',
    secondary_muscles: ['triceps'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Banco declinado a -15° ou -30°. Reduz a sobrecarga nos deltoides anteriores.',
      'Foco direto na porção costal e inferior do peitoral.',
    ],
  },
  {
    id: 'ex-spoto-press',
    name: 'Supino Spoto Pausado com Barra (Spoto Press)',
    target_muscle: 'chest',
    secondary_muscles: ['triceps', 'shoulders'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pause a barra a 2-3 cm do peito no ar por 1 segundo antes de explodir para cima.',
      'Constrói força de aceleração e controle isométrico brutal no ponto crítico do supino.',
    ],
  },
  {
    id: 'ex-floor-press',
    name: 'Supino no Chão com Barra ou Halteres (Floor Press)',
    target_muscle: 'chest',
    secondary_muscles: ['triceps'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Deite-se no solo. Desça os braços até os tríceps tocarem o chão suavemente.',
      'Elimina o reflexo elástico e foca na transição de força e bloqueio dos tríceps.',
    ],
  },
  {
    id: 'ex-larsen-press',
    name: 'Supino Larsen com Pernas Suspensas (Larsen Press)',
    target_muscle: 'chest',
    secondary_muscles: ['triceps', 'shoulders'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pernas esticadas para frente sem tocar o chão, eliminando o leg drive.',
      'Exige estabilização pura do tronco e contração máxima do peitoral.',
    ],
  },
  {
    id: 'ex-chest-fly-dumbbell',
    name: 'Crucifixo Reto com Halteres',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Cotovelos levemente flexionados em arco estático.',
      'Abra os braços lateralmente até sentir alongamento profundo e junte abraçando um barril.',
    ],
  },
  {
    id: 'ex-incline-chest-fly',
    name: 'Crucifixo Inclinado com Halteres',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'No banco inclinado a 30°, abra os halteres desenhando um semi-círculo no ar.',
    ],
  },
  {
    id: 'ex-pec-deck',
    name: 'Voador / Pec Deck na Máquina',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Regule a altura do assento para as mãos ficarem no meio do peito.',
      'Aperte com força no centro mantendo as escápulas coladas no encosto.',
    ],
  },
  {
    id: 'ex-cable-crossover-high',
    name: 'Crossover na Polia Alta (Foco Porção Inferior)',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Puxe os cabos de cima para baixo cruzando as mãos à frente do quadril.',
    ],
  },
  {
    id: 'ex-cable-crossover-low',
    name: 'Crossover na Polia Baixa (Foco Porção Clavicular)',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Puxe os cabos de baixo para cima convergindo na altura dos olhos.',
    ],
  },
  {
    id: 'ex-cable-crossover-mid',
    name: 'Crossover na Polia Média (Alinhamento Horizontal)',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Cabos na altura do peito, empurrando para a frente com pico de contração central.',
    ],
  },
  {
    id: 'ex-dips-chest',
    name: 'Paralelas com Foco em Peitoral (Chest Dips com Peso)',
    target_muscle: 'chest',
    secondary_muscles: ['triceps', 'shoulders'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1598971639058-fab3c3109a00?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Incline o tronco para a frente a ~30° e abra levemente os cotovelos.',
      'Desça até 90° nos cotovelos e suba com potência peitoral.',
    ],
  },
  {
    id: 'ex-pushup-standard',
    name: 'Flexão de Braços Clássica / Com Carga nas Costas',
    target_muscle: 'chest',
    secondary_muscles: ['triceps', 'core'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Corpo reto em prancha, desça até o peito quase tocar o chão.',
    ],
  },

  // =========================================================================
  // 3. COSTAS & DORSAIS (BACK & LATS)
  // =========================================================================
  {
    id: 'ex-barbell-row',
    name: 'Remada Curvada com Barra (Barbell Row Pronada ou Supinada)',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'forearms', 'core'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Tronco inclinado a 45° ou paralelo ao solo com coluna travada.',
      'Puxe a barra em direção ao umbigo puxando com os cotovelos para trás.',
      'Esmague as escápulas no topo por 1 segundo.',
    ],
  },
  {
    id: 'ex-pendlay-row',
    name: 'Remada Pendlay com Barra (Pendlay Row - Saída do Solo)',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'core', 'forearms'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Tronco rigorosamente paralelo ao chão. A barra descansa no solo a cada repetição.',
      'Puxe explosivamente em direção ao esterno sem elevar o ângulo do tronco.',
      'Padrão ouro para potência e espessura das costas.',
    ],
  },
  {
    id: 'ex-tbar-row',
    name: 'Remada Cavalinho com Pegada Neutra (T-Bar Row)',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'shoulders', 'core'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pise nas plataformas com a barra entre as pernas segurando no triângulo.',
      'Puxe firme com amplitude total contraindo os romboides e grande dorsal.',
    ],
  },
  {
    id: 'ex-meadows-row',
    name: 'Remada Meadows com Barra T Unilateral',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'forearms'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Posicione-se perpendicular à barra landmine, segurando na ponta com pegada pronada.',
      'Puxe o cotovelo para cima e para trás com foco cirúrgico no grande dorsal.',
    ],
  },
  {
    id: 'ex-dumbbell-row',
    name: 'Remada Unilateral com Halter (Serrote)',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'forearms'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Joelho e mão apoiados no banco. Puxe o halter em direção ao quadril.',
      'Alongue a grande dorsal na descida sem girar a coluna.',
    ],
  },
  {
    id: 'ex-chest-supported-row',
    name: 'Remada Apoiada no Banco Inclinado com Halteres',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'shoulders'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Deite de peito no banco a 30°-45°. Elimina o cansaço na lombar.',
      'Puxe os halteres focando na contração pura dos retratores da escápula.',
    ],
  },
  {
    id: 'ex-lat-pulldown',
    name: 'Puxada Alta Aberta no Pulley (Lat Pulldown Pronado)',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'forearms'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pegada mais larga que os ombros, peito erguido com leve inclinação dorsal.',
      'Puxe a barra até a altura da clavícula direcionando os cotovelos para os bolsos da calça.',
    ],
  },
  {
    id: 'ex-lat-pulldown-neutral',
    name: 'Puxada Alta com Triângulo ou Pegada Neutra',
    target_muscle: 'back',
    secondary_muscles: ['biceps'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Puxe a manopla neutra rente ao peito com excelente ativação da parte inferior do dorsal.',
    ],
  },
  {
    id: 'ex-lat-pulldown-single',
    name: 'Puxada Alta Unilateral no Cabo (Lat Prayer Unilateral)',
    target_muscle: 'back',
    secondary_muscles: ['biceps'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Ajoelhado ou sentado, puxe a manopla focando na rotação natural e conexão mente-músculo.',
    ],
  },
  {
    id: 'ex-pullup-standard',
    name: 'Barra Fixa com Peso / Livre (Pull-up Pronada ou Neutra)',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'forearms', 'core'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1598971639058-fab3c3109a00?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pendure-se com amplitude completa até extensão total dos braços.',
      'Puxe até o queixo ultrapassar a barra.',
    ],
  },
  {
    id: 'ex-chinup-standard',
    name: 'Barra Fixa Supinada (Chin-up)',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'core'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1598971639058-fab3c3109a00?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Palmas viradas para você, recrutando pesadamente o bíceps em conjunto com o dorsal.',
    ],
  },
  {
    id: 'ex-seated-cable-row',
    name: 'Remada Baixa no Triângulo (Seated Cable Row)',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'forearms'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pés na plataforma com joelhos semiflexionados. Puxe o triângulo no abdômen.',
    ],
  },
  {
    id: 'ex-pullover-dumbbell',
    name: 'Pullover com Halter no Banco',
    target_muscle: 'back',
    secondary_muscles: ['chest', 'triceps'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Deite perpendicular ao banco segurando a anilha do halter com as duas mãos.',
      'Desça os braços atrás da cabeça expandindo a caixa torácica e puxando com os dorsais.',
    ],
  },
  {
    id: 'ex-pullover-cable',
    name: 'Pullover no Cabo com Barra Reta ou Corda (Lat Pushdown)',
    target_muscle: 'back',
    secondary_muscles: ['triceps'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Braços quase retos empurrando a barra do nível do rosto até a frente das coxas.',
    ],
  },

  // =========================================================================
  // 4. OMBROS & DELTOIDES (SHOULDERS)
  // =========================================================================
  {
    id: 'ex-overhead-press',
    name: 'Desenvolvimento Militar em Pé com Barra (OHP)',
    target_muscle: 'shoulders',
    secondary_muscles: ['triceps', 'core'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pés na largura dos ombros, glúteos e abdômen contraídos.',
      'Empurre a barra para cima em trajetória vertical, passando a cabeça para a frente no topo.',
    ],
  },
  {
    id: 'ex-dumbbell-shoulder-press',
    name: 'Desenvolvimento com Halteres Sentado',
    target_muscle: 'shoulders',
    secondary_muscles: ['triceps'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Banco a 75°-85°. Empurre os halteres para cima com trajetória ligeiramente convergente.',
    ],
  },
  {
    id: 'ex-arnold-press',
    name: 'Desenvolvimento Arnold com Halteres',
    target_muscle: 'shoulders',
    secondary_muscles: ['triceps'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Inicie com as palmas voltadas para você na altura do queixo.',
      'Gire os punhos 180° enquanto eleva os halteres acima da cabeça.',
    ],
  },
  {
    id: 'ex-machine-shoulder-press',
    name: 'Desenvolvimento na Máquina Articulada ou Smith',
    target_muscle: 'shoulders',
    secondary_muscles: ['triceps'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Excelente estabilização para progredir carga pura no deltoide anterior e medial.',
    ],
  },
  {
    id: 'ex-lateral-raise-dumbbell',
    name: 'Elevação Lateral com Halteres',
    target_muscle: 'shoulders',
    secondary_muscles: [],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Tronco levemente inclinado para a frente, cotovelos levemente fletidos.',
      'Eleve os braços lateralmente até a altura dos ombros sem dar impulso com as pernas.',
    ],
  },
  {
    id: 'ex-lateral-raise-cable',
    name: 'Elevação Lateral na Polia com Cabo',
    target_muscle: 'shoulders',
    secondary_muscles: [],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Cabo na altura do joelho ou solo. Mantém tensão mecânica contínua desde o início do movimento.',
    ],
  },
  {
    id: 'ex-cable-lateral-raise-behind',
    name: 'Elevação Lateral na Polia por Trás das Costas',
    target_muscle: 'shoulders',
    secondary_muscles: [],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Passe o cabo por trás do corpo puxando lateralmente, isolando o feixe lateral.',
    ],
  },
  {
    id: 'ex-front-raise-dumbbell',
    name: 'Elevação Frontal com Halteres ou Barra',
    target_muscle: 'shoulders',
    secondary_muscles: ['chest'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Eleve o peso à frente até a linha dos olhos com controle excêntrico.',
    ],
  },
  {
    id: 'ex-rear-delt-fly-dumbbell',
    name: 'Crucifixo Inverso no Banco Inclinado com Halteres',
    target_muscle: 'shoulders',
    secondary_muscles: ['back'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Deite de bruços no banco inclinado e abra os braços focando no deltoide posterior.',
    ],
  },
  {
    id: 'ex-face-pull',
    name: 'Face Pull com Corda na Polia Alta',
    target_muscle: 'shoulders',
    secondary_muscles: ['back'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Puxe a corda em direção à testa/olhos rodando os punhos para fora.',
      'Essencial para saúde dos rotadores e postura dos ombros.',
    ],
  },
  {
    id: 'ex-shrug-barbell',
    name: 'Encolhimento com Barra ou Halteres (Shrugs para Trapézio)',
    target_muscle: 'shoulders',
    secondary_muscles: ['forearms'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Eleve os ombros diretamente em direção às orelhas sem rolar a articulação.',
    ],
  },

  // =========================================================================
  // 5. BÍCEPS & ANTEBRAÇO (BICEPS & FOREARMS)
  // =========================================================================
  {
    id: 'ex-biceps-curl',
    name: 'Rosca Direta com Barra Reta ou Barra W',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Cotovelos colados ao lado do corpo, flexionando até contração total sem balançar o tronco.',
    ],
  },
  {
    id: 'ex-dumbbell-curl-alt',
    name: 'Rosca Alternada com Halteres com Supinação',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Comece com pegada neutra e supine o punho (palma para cima) durante a subida.',
    ],
  },
  {
    id: 'ex-incline-dumbbell-curl',
    name: 'Rosca Inclinada com Halteres no Banco 45°',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Banco inclinado a 45°. Alonga a cabeça longa do bíceps no ponto inicial.',
    ],
  },
  {
    id: 'ex-preacher-curl',
    name: 'Rosca Scott com Barra W ou na Máquina',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Braços apoiados no banco Scott impedindo qualquer roubo do corpo.',
    ],
  },
  {
    id: 'ex-hammer-curl',
    name: 'Rosca Martelo com Halteres ou Corda',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pegada neutra (palmas apontadas uma para a outra). Constrói o braquial e braquiorradial.',
    ],
  },
  {
    id: 'ex-spider-curl',
    name: 'Rosca Aranha no Banco Inclinado (Spider Curl)',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Deite de bruços no banco inclinado e flexione a barra à frente sem movimento de cotovelos.',
    ],
  },
  {
    id: 'ex-bayesian-curl',
    name: 'Rosca Bayesian no Cabo (Bíceps na Polia por Trás)',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Dê um passo à frente da polia com o braço estendido para trás, flexionando em arco.',
    ],
  },
  {
    id: 'ex-farmers-walk',
    name: 'Caminhada do Fazendeiro (Farmer Walk com Halteres / Trap Bar)',
    target_muscle: 'forearms',
    secondary_muscles: ['core', 'shoulders', 'calves'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Caminhe com carga pesada em cada mão mantendo postura ereta e pegada esmagadora.',
    ],
  },
  {
    id: 'ex-wrist-curl',
    name: 'Rosca Punho com Barra (Flexores de Punho)',
    target_muscle: 'forearms',
    secondary_muscles: [],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Antebraços apoiados nas coxas ou no banco, flexionando os punhos para cima.',
    ],
  },
  {
    id: 'ex-reverse-wrist-curl',
    name: 'Rosca Punho Inversa com Barra (Extensores de Punho)',
    target_muscle: 'forearms',
    secondary_muscles: [],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Palmas para baixo, estendendo os punhos em direção ao teto.',
    ],
  },

  // =========================================================================
  // 6. TRÍCEPS (TRICEPS)
  // =========================================================================
  {
    id: 'ex-triceps-pushdown',
    name: 'Tríceps Pulley com Barra Reta ou Barra V',
    target_muscle: 'triceps',
    secondary_muscles: [],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Cotovelos travados na lateral do corpo, empurre a barra estendendo totalmente os braços.',
    ],
  },
  {
    id: 'ex-triceps-rope-pushdown',
    name: 'Tríceps Pulley com Corda na Polia',
    target_muscle: 'triceps',
    secondary_muscles: [],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Abra as pontas da corda na parte inferior para contração máxima da cabeça lateral.',
    ],
  },
  {
    id: 'ex-skull-crusher',
    name: 'Tríceps Testa com Barra W ou Halteres (Skull Crusher)',
    target_muscle: 'triceps',
    secondary_muscles: [],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Deitado no banco, desça a barra W em direção à testa ou ligeiramente atrás da cabeça.',
    ],
  },
  {
    id: 'ex-french-press',
    name: 'Tríceps Francês com Halter ou na Polia (Overhead Extension)',
    target_muscle: 'triceps',
    secondary_muscles: [],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Segure o halter acima da cabeça com as duas mãos, descendo atrás do pescoço para alongar a cabeça longa.',
    ],
  },
  {
    id: 'ex-triceps-kickback',
    name: 'Tríceps Coice no Cabo ou com Halter',
    target_muscle: 'triceps',
    secondary_muscles: [],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Tronco inclinado, estenda o antebraço para trás com pico de contração de 1s.',
    ],
  },
  {
    id: 'ex-dips-triceps',
    name: 'Paralelas com Foco em Tríceps (Corpo Vertical)',
    target_muscle: 'triceps',
    secondary_muscles: ['chest', 'shoulders'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1598971639058-fab3c3109a00?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Corpo reto, cotovelos fechados apontando para trás.',
    ],
  },

  // =========================================================================
  // 7. QUADRÍCEPS & COXAS (QUADRICEPS)
  // =========================================================================
  {
    id: 'ex-barbell-squat',
    name: 'Agachamento Livre com Barra Olímpica (Back Squat)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes', 'hamstrings', 'core'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Barra firme nos trapézios, pés na largura dos ombros com pontas ligeiramente para fora.',
      'Desça quebrando o paralelo (abaixo de 90°) mantendo o peito erguido.',
      'O exercício soberano para construção de pernas imponentes.',
    ],
  },
  {
    id: 'ex-front-squat',
    name: 'Agachamento Frontal com Barra (Front Squat)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['core', 'glutes'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Barra apoiada nos deltoides anteriores com cotovelos altos.',
      'Tronco completamente ereto focando 100% no quadríceps com mínimo estresse lombar.',
    ],
  },
  {
    id: 'ex-zercher-squat',
    name: 'Agachamento Zercher com Barra nos Cotovelos',
    target_muscle: 'quadriceps',
    secondary_muscles: ['core', 'glutes', 'back'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Segure a barra na dobra dos cotovelos mantendo os punhos juntos.',
      'Constrói uma força de núcleo abdominal e de quadríceps inabalável.',
    ],
  },
  {
    id: 'ex-leg-press-45',
    name: 'Leg Press 45° Articulado',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1434682881908-b43d0467b798?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Desça até 90° nos joelhos sem arredondar a lombar contra o encosto.',
      'Empurre através dos calcanhares sem bloquear os joelhos no topo.',
    ],
  },
  {
    id: 'ex-hack-squat',
    name: 'Hack Squat na Máquina 45°',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1434682881908-b43d0467b798?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pés na base da plataforma descendo profundamente com apoio estável.',
    ],
  },
  {
    id: 'ex-pendulum-squat',
    name: 'Agachamento Pendular na Máquina (Pendulum Squat)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1434682881908-b43d0467b798?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Curva de força biomecânica perfeita com alívio articular total na lombar e joelhos.',
    ],
  },
  {
    id: 'ex-leg-extension',
    name: 'Cadeira Extensora',
    target_muscle: 'quadriceps',
    secondary_muscles: [],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Estenda os joelhos completamente e segure 1 segundo no topo em contração máxima.',
    ],
  },
  {
    id: 'ex-bulgarian-split-squat',
    name: 'Agachamento Búlgaro com Halteres ou Smith',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes', 'hamstrings'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pé de trás apoiado no banco, desça até o joelho quase encostar no solo.',
    ],
  },
  {
    id: 'ex-walking-lunge',
    name: 'Passada / Afundo Caminhando com Halteres',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes', 'hamstrings'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Passos firmes mantendo ângulos de 90° em cada flexão de joelho.',
    ],
  },
  {
    id: 'ex-sissy-squat',
    name: 'Sissy Squat na Máquina ou Livre',
    target_muscle: 'quadriceps',
    secondary_muscles: ['core'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Isolamento brutal do reto femoral e vasto medial com amplitude alongada.',
    ],
  },

  // =========================================================================
  // 8. POSTERIORES DE COXA (HAMSTRINGS)
  // =========================================================================
  {
    id: 'ex-lying-leg-curl',
    name: 'Mesa Flexora Deitada',
    target_muscle: 'hamstrings',
    secondary_muscles: [],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1605296867304-46d5465a13f1?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Quadril colado no banco, puxe a almofada em direção aos glúteos e controle a volta.',
    ],
  },
  {
    id: 'ex-seated-leg-curl',
    name: 'Cadeira Flexora Sentada',
    target_muscle: 'hamstrings',
    secondary_muscles: [],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1605296867304-46d5465a13f1?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Quadril a 90° coloca os ísquios em pré-alongamento ideal para hipertrofia superior.',
    ],
  },
  {
    id: 'ex-standing-leg-curl',
    name: 'Flexora Unilateral em Pé na Máquina',
    target_muscle: 'hamstrings',
    secondary_muscles: [],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1605296867304-46d5465a13f1?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Flexão isolada corrigindo desequilíbrios entre as duas pernas.',
    ],
  },
  {
    id: 'ex-nordic-hamstring-curl',
    name: 'Flexão Nórdica no Solo (Nordic Hamstring Curl)',
    target_muscle: 'hamstrings',
    secondary_muscles: ['glutes', 'core'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1598971639058-fab3c3109a00?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pés fixados, desça o tronco em linha reta segurando a gravidade com a força dos posteriores.',
    ],
  },

  // =========================================================================
  // 9. GLÚTEOS (GLUTES)
  // =========================================================================
  {
    id: 'ex-hip-thrust-barbell',
    name: 'Elevação Pélvica com Barra Olímpica (Barbell Hip Thrust)',
    target_muscle: 'glutes',
    secondary_muscles: ['hamstrings', 'core'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Escápulas no banco, barra sobre a pelve com protetor de espuma.',
      'Eleve o quadril até ficar nivelado ao tronco e contraia os glúteos no topo por 1s.',
    ],
  },
  {
    id: 'ex-hip-thrust-machine',
    name: 'Elevação Pélvica na Máquina Específica',
    target_muscle: 'glutes',
    secondary_muscles: ['hamstrings'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1434682881908-b43d0467b798?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Carga guiada com amplitude máxima e conforto para cargas pesadas.',
    ],
  },
  {
    id: 'ex-abductor-machine',
    name: 'Cadeira Abdutora (Glúteo Médio e Mínimo)',
    target_muscle: 'glutes',
    secondary_muscles: [],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1434682881908-b43d0467b798?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Incline o tronco levemente para a frente para focar no feixe superior do glúteo.',
    ],
  },
  {
    id: 'ex-adductor-machine',
    name: 'Cadeira Adutora (Adutores da Coxa)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1434682881908-b43d0467b798?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Feche as pernas controlando o movimento excêntrico na abertura.',
    ],
  },
  {
    id: 'ex-cable-kickback',
    name: 'Glúteo no Cabo com Caneleira (Kickback no Cross)',
    target_muscle: 'glutes',
    secondary_muscles: ['hamstrings'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Chute diagonal para trás ativando glúteo máximo e estabilizadores.',
    ],
  },

  // =========================================================================
  // 10. PANTURRILHAS (CALVES)
  // =========================================================================
  {
    id: 'ex-standing-calf-raise',
    name: 'Elevação de Panturrilha em Pé na Máquina',
    target_muscle: 'calves',
    secondary_muscles: [],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Desça o calcanhar ao limite para esticar a fáscia e suba na ponta dos pés com pausa.',
    ],
  },
  {
    id: 'ex-seated-calf-raise',
    name: 'Elevação de Panturrilha Sentado (Gêmeos no Banco)',
    target_muscle: 'calves',
    secondary_muscles: [],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Joelhos a 90° isolam o músculo sóleo profundo.',
    ],
  },
  {
    id: 'ex-leg-press-calf-raise',
    name: 'Panturrilha no Leg Press 45°',
    target_muscle: 'calves',
    secondary_muscles: [],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pontas dos pés na borda da plataforma mantendo os joelhos com microflexão.',
    ],
  },

  // =========================================================================
  // 11. ABDÔMEN & CORE
  // =========================================================================
  {
    id: 'ex-cable-crunch',
    name: 'Abdominal no Cabo com Corda na Polia Alta (Cable Crunch)',
    target_muscle: 'core',
    secondary_muscles: [],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'De joelhos, segure a corda ao lado da cabeça e enrole o tronco aproximando as costelas da bacia.',
    ],
  },
  {
    id: 'ex-hanging-leg-raise',
    name: 'Elevação de Pernas na Barra Fixa (Hanging Leg Raise)',
    target_muscle: 'core',
    secondary_muscles: ['forearms'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pendurado na barra, eleve os pés até a altura da barra sem balançar o corpo.',
    ],
  },
  {
    id: 'ex-ab-wheel-roller',
    name: 'Roda Abdominal no Solo (Ab Wheel Roller)',
    target_muscle: 'core',
    secondary_muscles: ['shoulders', 'back'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Role à frente mantendo a pelve em retroversão e o abdômen tensionado ao máximo.',
    ],
  },
  {
    id: 'ex-dragon-flag',
    name: 'Dragon Flag no Banco Reto (Estilo Bruce Lee)',
    target_muscle: 'core',
    secondary_muscles: ['back', 'shoulders'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Segure o banco atrás da cabeça e eleve o corpo todo como uma tábua esticada.',
    ],
  },
  {
    id: 'ex-plank-standard',
    name: 'Prancha Isométrica no Solo com Carga / Peso',
    target_muscle: 'core',
    secondary_muscles: ['shoulders'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Linha reta perfeita da cabeça aos calcanhares por 45 a 90 segundos com anilha nas costas.',
    ],
  },
  {
    id: 'ex-russian-twist',
    name: 'Russian Twist com Anilha / Halter (Oblíquos)',
    target_muscle: 'core',
    secondary_muscles: [],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pés suspensos e tronco a 45°, rodando a anilha lateralmente com controle.',
    ],
  },
  {
    id: 'ex-vacuum-abdominal',
    name: 'Vacuum Abdominal (Transverso do Abdômen)',
    target_muscle: 'core',
    secondary_muscles: [],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Solte todo o ar dos pulmões e sugue o umbigo em direção à coluna por 20 segundos.',
    ],
  },

  // =========================================================================
  // EXERCÍCIOS EXPANDIDOS: PEITORAL ADICIONAIS
  // =========================================================================
  {
    id: 'ex-bench-press-decline-dumbbell',
    name: 'Supino Declinado com Halteres',
    target_muscle: 'chest',
    secondary_muscles: ['triceps', 'shoulders'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Deite-se no banco declinado e empurre os halteres para cima alinhados ao peito inferior.',
    ],
  },
  {
    id: 'ex-bench-press-smith',
    name: 'Supino Reto na Máquina Smith',
    target_muscle: 'chest',
    secondary_muscles: ['triceps', 'shoulders'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Posicione o banco centralizado na barra guiada para segurança máxima em cargas altas.',
    ],
  },
  {
    id: 'ex-incline-bench-smith',
    name: 'Supino Inclinado na Máquina Smith',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders', 'triceps'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Banco a 30° no Smith focando o estímulo na porção superior clavicular do peitoral.',
    ],
  },
  {
    id: 'ex-close-grip-bench',
    name: 'Supino com Pegada Fechada (Close-Grip Bench Press)',
    target_muscle: 'triceps',
    secondary_muscles: ['chest', 'shoulders'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pegada na largura dos ombros mantendo os cotovelos rentes ao tronco.',
    ],
  },
  {
    id: 'ex-guillotine-press',
    name: 'Supino Guilhotina com Barra (Gironda Neck Press)',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Desça a barra em direção ao pescoço com pegada aberta e cotovelos abertos para alongamento peitoral extremo.',
    ],
  },
  {
    id: 'ex-decline-pushup',
    name: 'Flexão de Braços Declinada (Pés no Banco)',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders', 'triceps'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pés elevados no banco para transferir maior sobrecarga ao peitoral superior.',
    ],
  },
  {
    id: 'ex-incline-pushup',
    name: 'Flexão de Braços Inclinada (Mãos no Banco)',
    target_muscle: 'chest',
    secondary_muscles: ['triceps'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Mãos apoiadas no banco facilitando a alavanca para maior controle e repetições.',
    ],
  },

  // =========================================================================
  // EXERCÍCIOS EXPANDIDOS: COSTAS & DORSAIS ADICIONAIS
  // =========================================================================
  {
    id: 'ex-pullup-neutral',
    name: 'Barra Fixa com Pegada Neutra Fechada',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'forearms'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1598971639058-fab3c3109a00?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Palmas viradas uma para a outra reduzindo o estresse no punho e ombro.',
    ],
  },
  {
    id: 'ex-graviton-pullup',
    name: 'Barra Fixa Assistida na Máquina (Graviton)',
    target_muscle: 'back',
    secondary_muscles: ['biceps'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Contra-peso calibrado para desenvolver força de puxada progressiva.',
    ],
  },
  {
    id: 'ex-lat-pulldown-v-bar',
    name: 'Puxada Alta com Barra V no Pulley',
    target_muscle: 'back',
    secondary_muscles: ['biceps'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Puxe a manopla V rente ao peito focando na parte inferior dos dorsais.',
    ],
  },
  {
    id: 'ex-machine-row-neutral',
    name: 'Remada Articulada na Máquina (Pegada Neutra)',
    target_muscle: 'back',
    secondary_muscles: ['biceps'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Peito apoiado na almofada puxando as alavancas com amplitude máxima.',
    ],
  },
  {
    id: 'ex-machine-row-pronated',
    name: 'Remada Articulada na Máquina (Pegada Pronada Aberta)',
    target_muscle: 'back',
    secondary_muscles: ['shoulders', 'biceps'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pegada mais larga com foco na musculatura média e alta das costas (romboides e trapézio).',
    ],
  },
  {
    id: 'ex-inverted-row',
    name: 'Remada Invertida na Barra Smith ou TRX (Inverted Row)',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'core'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1598971639058-fab3c3109a00?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Corpo reto sob a barra, puxando o peito até a barra com força dorsal.',
    ],
  },
  {
    id: 'ex-upright-row-barbell',
    name: 'Remada Alta com Barra (Upright Row)',
    target_muscle: 'shoulders',
    secondary_muscles: ['back', 'biceps'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Puxe a barra verticalmente até a altura do peito com cotovelos acima dos punhos.',
    ],
  },
  {
    id: 'ex-upright-row-cable',
    name: 'Remada Alta na Polia Baixa com Barra Reta',
    target_muscle: 'shoulders',
    secondary_muscles: ['back'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Tensão contínua puxando a barra rente ao corpo para deltoides e trapézio.',
    ],
  },
  {
    id: 'ex-shrug-smith',
    name: 'Encolhimento de Ombros na Máquina Smith',
    target_muscle: 'shoulders',
    secondary_muscles: ['forearms'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Elevação estrita do trapézio na trajetória linear da barra guiada.',
    ],
  },
  {
    id: 'ex-shrug-dumbbell-seated',
    name: 'Encolhimento com Halteres Sentado no Banco',
    target_muscle: 'shoulders',
    secondary_muscles: [],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Sentado elimina qualquer impulso com os joelhos para trabalho puro no trapézio.',
    ],
  },

  // =========================================================================
  // EXERCÍCIOS EXPANDIDOS: CADEIA POSTERIOR & GLÚTEOS ADICIONAIS
  // =========================================================================
  {
    id: 'ex-jefferson-deadlift',
    name: 'Levantamento Terra Jefferson (Jefferson Squat/Deadlift)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes', 'back', 'hamstrings'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Fique sobre a barra com uma perna na frente e outra atrás, erguendo o peso com força assimétrica.',
    ],
  },
  {
    id: 'ex-stiff-smith',
    name: 'Stiff na Máquina Smith',
    target_muscle: 'hamstrings',
    secondary_muscles: ['glutes', 'back'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Trajetória guiada permitindo focar 100% no estiramento dos ísquiotibiais.',
    ],
  },
  {
    id: 'ex-good-morning-seated',
    name: 'Bom Dia Sentado no Banco com Barra',
    target_muscle: 'hamstrings',
    secondary_muscles: ['back', 'glutes'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Sentado no banco, incline o tronco à frente fortalecendo os eretores da espinha e adutores.',
    ],
  },
  {
    id: 'ex-hyperextension-45',
    name: 'Hiperextensão Lombar no Banco 45°',
    target_muscle: 'back',
    secondary_muscles: ['glutes', 'hamstrings'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Desça o tronco flexionando o quadril e suba alinhando com as pernas sem forçar a cervical.',
    ],
  },
  {
    id: 'ex-superman',
    name: 'Hiperextensão Lombar no Solo (Superman)',
    target_muscle: 'back',
    secondary_muscles: ['glutes'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Deitado de bruços, eleve braços e pernas simultaneamente sustentando a contração.',
    ],
  },
  {
    id: 'ex-single-leg-hip-thrust',
    name: 'Elevação Pélvica Unilateral (Single-Leg Hip Thrust)',
    target_muscle: 'glutes',
    secondary_muscles: ['hamstrings', 'core'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Uma perna apoiada no chão e outra elevada estendendo o quadril de forma isolada.',
    ],
  },
  {
    id: 'ex-glute-bridge-floor',
    name: 'Ponte de Glúteos no Solo com Anilha',
    target_muscle: 'glutes',
    secondary_muscles: ['hamstrings'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Deitado no colchonete com os joelhos dobrados, eleve a bacia contraindo os glúteos.',
    ],
  },

  // =========================================================================
  // EXERCÍCIOS EXPANDIDOS: QUADRÍCEPS & PERNAS ADICIONAIS
  // =========================================================================
  {
    id: 'ex-goblet-squat',
    name: 'Agachamento Taça com Halter ou Kettlebell (Goblet Squat)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes', 'core'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Segure o halter na vertical junto ao peito e agache profundamente com cotovelos por dentro dos joelhos.',
    ],
  },
  {
    id: 'ex-sumo-squat-barbell',
    name: 'Agachamento Sumô com Barra Livre',
    target_muscle: 'glutes',
    secondary_muscles: ['quadriceps', 'hamstrings'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pés bem afastados com pontas a 45° agachando profundo para ênfase em adutores e glúteos.',
    ],
  },
  {
    id: 'ex-wall-sit',
    name: 'Agachamento Isométrico na Parede (Wall Sit)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Costas apoiadas na parede e joelhos flexionados a 90° sustentando o tempo estipulado.',
    ],
  },
  {
    id: 'ex-pistol-squat',
    name: 'Agachamento Pistol Unilateral (Pistol Squat)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes', 'core'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Agache em uma única perna com a outra perna estendida à frente.',
    ],
  },
  {
    id: 'ex-cossack-squat',
    name: 'Agachamento Cossaco Lateral (Cossack Squat)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Agache lateralmente de um lado mantendo a perna oposta estendida para mobilidade e força.',
    ],
  },
  {
    id: 'ex-reverse-lunge-dumbbell',
    name: 'Afundo Reverso com Halteres (Passada para Trás)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes', 'hamstrings'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Dê o passo para trás protegendo o joelho frontal com sobrecarga estável.',
    ],
  },
  {
    id: 'ex-lunge-smith',
    name: 'Afundo Estático na Máquina Smith',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Posição de tesoura descendo até o joelho de trás quase encostar no chão com barra guiada.',
    ],
  },
  {
    id: 'ex-step-up-dumbbell',
    name: 'Subida no Banco com Halteres (Step-Up)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pise no banco alto e empurre através do calcanhar subindo com controle.',
    ],
  },
  {
    id: 'ex-horizontal-leg-press',
    name: 'Leg Press Horizontal na Máquina',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1434682881908-b43d0467b798?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Empurre o trenó horizontalmente com apoio confortável para a coluna.',
    ],
  },
  {
    id: 'ex-single-leg-press-45',
    name: 'Leg Press 45° Unilateral',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1434682881908-b43d0467b798?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Uma perna de cada vez eliminando assimetrias de força e hipertrofia.',
    ],
  },
  {
    id: 'ex-single-leg-extension',
    name: 'Cadeira Extensora Unilateral',
    target_muscle: 'quadriceps',
    secondary_muscles: [],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Extensão de uma perna por vez para isolamento cirúrgico de cada coxa.',
    ],
  },
  {
    id: 'ex-single-leg-curl-lying',
    name: 'Mesa Flexora Unilateral',
    target_muscle: 'hamstrings',
    secondary_muscles: [],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1605296867304-46d5465a13f1?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Flexão de joelho individual com cadência controlada.',
    ],
  },

  // =========================================================================
  // EXERCÍCIOS EXPANDIDOS: OMBROS & DELTOIDES ADICIONAIS
  // =========================================================================
  {
    id: 'ex-behind-neck-press',
    name: 'Desenvolvimento Militar Atrás da Nuca com Barra',
    target_muscle: 'shoulders',
    secondary_muscles: ['triceps'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Desça a barra cuidadosamente até a linha superior da nuca com controle articular.',
    ],
  },
  {
    id: 'ex-neutral-shoulder-press-dumbbell',
    name: 'Desenvolvimento com Halteres com Pegada Neutra',
    target_muscle: 'shoulders',
    secondary_muscles: ['triceps'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Palmas viradas para dentro aliviando o impacto no manguito rotador.',
    ],
  },
  {
    id: 'ex-landmine-shoulder-press',
    name: 'Desenvolvimento Landmine Unilateral com Barra',
    target_muscle: 'shoulders',
    secondary_muscles: ['triceps', 'core'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Empurre a ponta da barra presa no solo em trajetória diagonal natural.',
    ],
  },
  {
    id: 'ex-incline-lateral-raise',
    name: 'Elevação Lateral no Banco Inclinado com Halter',
    target_muscle: 'shoulders',
    secondary_muscles: [],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Deite-se de lado no banco inclinado e eleve o braço para tensão no deltoide medial.',
    ],
  },
  {
    id: 'ex-machine-lateral-raise',
    name: 'Elevação Lateral na Máquina Articulada',
    target_muscle: 'shoulders',
    secondary_muscles: [],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Braços apoiados nas almofadas elevando lateralmente com isolamento biomecânico.',
    ],
  },
  {
    id: 'ex-cable-front-raise',
    name: 'Elevação Frontal na Polia Baixa com Barra Reta',
    target_muscle: 'shoulders',
    secondary_muscles: ['chest'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Puxe o cabo entre as pernas elevando a barra até o nível dos olhos.',
    ],
  },
  {
    id: 'ex-plate-front-raise',
    name: 'Elevação Frontal com Anilha',
    target_muscle: 'shoulders',
    secondary_muscles: ['chest'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Segure a anilha nas laterais elevando até a altura do rosto com braços quase retos.',
    ],
  },
  {
    id: 'ex-reverse-pec-deck',
    name: 'Crucifixo Inverso no Voador (Pec Deck Invertido)',
    target_muscle: 'shoulders',
    secondary_muscles: ['back'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'De peito no encosto do voador, empurre as alavancas para trás contraindo o posterior de ombro.',
    ],
  },
  {
    id: 'ex-external-rotation-cable',
    name: 'Rotação Externa de Ombro na Polia (Manguito Rotador)',
    target_muscle: 'shoulders',
    secondary_muscles: [],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Cotovelo colado a 90°, gire o punho para fora fortalecendo o manguito rotador.',
    ],
  },

  // =========================================================================
  // EXERCÍCIOS EXPANDIDOS: BÍCEPS & ANTEBRAÇO ADICIONAIS
  // =========================================================================
  {
    id: 'ex-concentration-curl',
    name: 'Rosca Concentrada com Halter no Banco',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Cotovelo apoiado na parte interna da coxa flexionando com isolamento no pico do bíceps.',
    ],
  },
  {
    id: 'ex-21s-bicep-curl',
    name: 'Rosca 21 com Barra W (Método 21 Reps)',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      '7 reps na metade inferior + 7 reps na metade superior + 7 reps completas sem descanso.',
    ],
  },
  {
    id: 'ex-drag-curl-barbell',
    name: 'Rosca Drag com Barra Reta (Drag Curl)',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Puxe a barra arrastando-a rente ao abdômen e peito com cotovelos projetados para trás.',
    ],
  },
  {
    id: 'ex-cross-body-hammer-curl',
    name: 'Rosca Martelo Cruzada no Peito',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Flexione o halter em direção ao peitoral oposto enfatizando o músculo braquial.',
    ],
  },
  {
    id: 'ex-single-preacher-curl',
    name: 'Rosca Scott Unilateral com Halter',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Braço individual apoiado no banco Scott garantindo simetria de força nos bíceps.',
    ],
  },
  {
    id: 'ex-zottman-curl',
    name: 'Rosca Zottman com Halteres',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Suba com pegada supinada (palmas para cima) e desça com pegada pronada (palmas para baixo).',
    ],
  },
  {
    id: 'ex-hercules-cable-curl',
    name: 'Rosca Hércules na Polia Alta Dupla',
    target_muscle: 'biceps',
    secondary_muscles: [],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'No meio do crossover alto, flexione os braços em direção às orelhas simulando duplo bíceps.',
    ],
  },
  {
    id: 'ex-reverse-barbell-curl',
    name: 'Rosca Inversa com Barra Reta (Braquiorradial)',
    target_muscle: 'forearms',
    secondary_muscles: ['biceps'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pegada pronada completa erguendo a barra com força predominante nos antebraços.',
    ],
  },

  // =========================================================================
  // EXERCÍCIOS EXPANDIDOS: TRÍCEPS ADICIONAIS
  // =========================================================================
  {
    id: 'ex-decline-skull-crusher',
    name: 'Tríceps Testa no Banco Declinado com Barra W',
    target_muscle: 'triceps',
    secondary_muscles: [],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'O declive mantém a tensão mecânica constante no ponto alto da extensão.',
    ],
  },
  {
    id: 'ex-dumbbell-skull-crusher',
    name: 'Tríceps Testa com Halteres no Banco Reto',
    target_muscle: 'triceps',
    secondary_muscles: [],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pegada neutra descendo os halteres ao lado da cabeça com amplitude estendida.',
    ],
  },
  {
    id: 'ex-cable-french-press',
    name: 'Tríceps Francês na Polia Baixa com Corda',
    target_muscle: 'triceps',
    secondary_muscles: [],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'De costas para a polia, estenda os braços acima da cabeça esticando a corda.',
    ],
  },
  {
    id: 'ex-dip-machine',
    name: 'Tríceps na Máquina de Mergulho Sentado (Dip Machine)',
    target_muscle: 'triceps',
    secondary_muscles: ['chest', 'shoulders'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Sentado na máquina, empurre as manoplas para baixo contra a resistência ajustada.',
    ],
  },
  {
    id: 'ex-reverse-grip-pushdown',
    name: 'Tríceps Pulley Invertido com Pegada Supinada',
    target_muscle: 'triceps',
    secondary_muscles: [],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Palmas viradas para cima empurrando a barra para baixo com foco na cabeça medial.',
    ],
  },

  // =========================================================================
  // EXERCÍCIOS EXPANDIDOS: PANTURRILHAS & TIBIAIS ADICIONAIS
  // =========================================================================
  {
    id: 'ex-smith-calf-raise',
    name: 'Panturrilha em Pé na Máquina Smith com Bloco',
    target_muscle: 'calves',
    secondary_muscles: [],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pontas dos pés no calço sob a barra Smith descendo calcanhares ao máximo antes de subir.',
    ],
  },
  {
    id: 'ex-single-leg-calf-raise',
    name: 'Panturrilha Unilateral no Degrau com Halter',
    target_muscle: 'calves',
    secondary_muscles: [],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Uma perna por vez no degrau sustentando o halter na mão homolateral.',
    ],
  },
  {
    id: 'ex-donkey-calf-raise',
    name: 'Elevação de Panturrilha Burrinho (Donkey Calf Raise)',
    target_muscle: 'calves',
    secondary_muscles: [],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Tronco a 90° com apoio lombar alongando os gastrocnêmios profundamente.',
    ],
  },
  {
    id: 'ex-tibialis-raise',
    name: 'Elevação de Tibial Anterior (Tibialis Raise)',
    target_muscle: 'calves',
    secondary_muscles: [],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Encostado na parede com pernas estendidas, flexione os pés para cima fortalecendo a canela.',
    ],
  },

  // =========================================================================
  // EXERCÍCIOS EXPANDIDOS: ABDÔMEN & CORE ADICIONAIS
  // =========================================================================
  {
    id: 'ex-sit-up-decline',
    name: 'Abdominal no Banco Declinado com Anilha no Peito',
    target_muscle: 'core',
    secondary_muscles: [],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pés travados, suba o tronco contra a gravidade sustentando a anilha sobre o peito.',
    ],
  },
  {
    id: 'ex-v-up-crunch',
    name: 'Abdominal Canivete no Solo (V-Up)',
    target_muscle: 'core',
    secondary_muscles: [],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Eleve mãos e pés simultaneamente formando um V no topo com o tronco.',
    ],
  },
  {
    id: 'ex-bicycle-crunch',
    name: 'Abdominal Bicicleta no Solo (Bicycle Crunch)',
    target_muscle: 'core',
    secondary_muscles: [],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Gire o tronco levando o cotovelo de encontro ao joelho oposto alternadamente.',
    ],
  },
  {
    id: 'ex-hanging-knee-raise',
    name: 'Elevação de Joelhos na Barra Fixa (Hanging Knee Raise)',
    target_muscle: 'core',
    secondary_muscles: ['forearms'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pendurado na barra, puxe os joelhos em direção ao peitoral enrolando a pelve.',
    ],
  },
  {
    id: 'ex-captains-chair-knee-raise',
    name: 'Elevação de Pernas na Cadeira do Capitão (Paralela)',
    target_muscle: 'core',
    secondary_muscles: [],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Antebraços apoiados nas almofadas elevando pernas ou joelhos com estabilidade.',
    ],
  },
  {
    id: 'ex-side-plank',
    name: 'Prancha Lateral Isométrica no Solo (Side Plank)',
    target_muscle: 'core',
    secondary_muscles: [],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Apoie o antebraço lateral e mantenha o quadril alto alinhado à cabeça.',
    ],
  },
  {
    id: 'ex-woodchopper-cable',
    name: 'Abdominal Woodchopper Diagonal na Polia (Oblíquos)',
    target_muscle: 'core',
    secondary_muscles: ['shoulders'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Puxe o cabo em diagonal cruzando o tronco com rotação poderosa de core.',
    ],
  },

  // =========================================================================
  // 11. EXERCÍCIOS ESPECÍFICOS DE HIPERTROFIA CIENTÍFICA & SUBSTITUIÇÕES
  // (Fichas e planilhas científicas / Pure Bodybuilding / Jeff Nippard & RP)
  // =========================================================================
  {
    id: 'ex-low-incline-dumbbell-press',
    name: 'Supino Inclinado com Halteres em Ângulo Baixo (Low-Incline DB Press 15°-30°)',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders', 'triceps'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Ajuste o banco em inclinação baixa de 15° a 30° para maximizar o peitoral clavicular e poupar o deltoide anterior.',
      'Escápulas aduzidas e deprimidas, descendo os halteres até sentir estiramento profundo no peitoral.',
      'Empurre convergindo levemente no topo sem bater os halteres, mantendo tensão contínua.',
    ],
  },
  {
    id: 'ex-low-incline-machine-press',
    name: 'Supino Inclinado na Máquina Articulada (Low-Incline Machine Press)',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders', 'triceps'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Ajuste a altura do assento para que as manoplas fiquem na linha superior do peitoral.',
      'Excelente estabilidade mecânica: empurre controlando a fase excêntrica de 2 a 3 segundos.',
    ],
  },
  {
    id: 'ex-incline-smith-press-30',
    name: 'Supino Inclinado no Smith Machine a 30° (Smith Incline Press)',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders', 'triceps'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Posicione o banco centralizado sob a barra com inclinação moderada.',
      'A barra deve descer suavemente na altura da clavícula, com cotovelos a 45°-60° do tronco.',
    ],
  },
  {
    id: 'ex-converging-chest-press-machine',
    name: 'Supino Reto na Máquina Convergente Articulada (Plate-Loaded Chest Press)',
    target_muscle: 'chest',
    secondary_muscles: ['triceps', 'shoulders'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'A trajetória convergente acompanha o padrão anatômico de adução horizontal das fibras peitorais.',
      'Mantenha as costas coladas no encosto e execute a contração máxima no fechamento.',
    ],
  },
  {
    id: 'ex-chest-dips-weighted',
    name: 'Paralelas com Tronco Inclinado para Peitoral (Weighted Chest Dips)',
    target_muscle: 'chest',
    secondary_muscles: ['triceps', 'shoulders'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Incline o tronco cerca de 30° para a frente e afaste levemente os cotovelos para transferir o torque para o peitoral inferior.',
      'Desça até os cotovelos atingirem 90° e suba empurrando com força peitoral.',
    ],
  },
  {
    id: 'ex-cable-crossover-high-low',
    name: 'Crossover na Polia Alta para Baixo (High-to-Low Cable Fly)',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Polias posicionadas no ponto mais alto. Dê um passo à frente com base firme.',
      'Traga os punhos para frente e para baixo em direção ao umbigo cruzando levemente as mãos.',
    ],
  },
  {
    id: 'ex-cable-crossover-low-high',
    name: 'Crossover na Polia Baixa para Cima (Low-to-High Clavicular Fly)',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Polias no ponto inferior. Puxe os cabos de baixo para cima na linha dos olhos.',
      'Foco em estiramento e contração da cabeça clavicular superior do peitoral.',
    ],
  },
  {
    id: 'ex-seated-cable-chest-fly',
    name: 'Crucifixo Sentado no Cabo com Apoio Lombar (Seated Cable Fly)',
    target_muscle: 'chest',
    secondary_muscles: ['shoulders'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'O apoio do banco elimina oscilações e compensações posturais.',
      'Abra os braços em arco amplo sentindo tensão constante em toda a amplitude de movimento.',
    ],
  },
  {
    id: 'ex-spoto-press-barbell',
    name: 'Supino Spoto com Pausa a 2cm do Peito (Spoto Press)',
    target_muscle: 'chest',
    secondary_muscles: ['triceps', 'shoulders'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Desça a barra controladamente e pare de forma estrita a 2-3cm do peitoral por 1 segundo.',
      'Elimina o reflexo miotático de estiramento, desenvolvendo força pura de reversão.',
    ],
  },
  {
    id: 'ex-constant-tension-lateral-raise',
    name: 'Elevação Lateral com Tensão Contínua com Halteres (Constant Tension DB Raise)',
    target_muscle: 'shoulders',
    secondary_muscles: ['back'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Eleve os braços em abdução no plano escapular até a altura do ombro.',
      'Na descida, pare antes dos halteres tocarem as coxas (a cerca de 20-30° do corpo), mantendo o deltoide lateral sob tensão ininterrupta.',
    ],
  },
  {
    id: 'ex-cross-body-cable-y-raise',
    name: 'Elevação em Y Cruzada na Polia (Cross-Body Cable Y-Raise)',
    target_muscle: 'shoulders',
    secondary_muscles: ['back'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Ajuste as polias na altura do quadril. Segure os cabos cruzados sem manoplas (pela ponta do cabo).',
      'Puxe os braços na diagonal formando um "Y" a 45° acima da cabeça, alinhando a linha de força com o deltoide lateral e trapézio inferior.',
    ],
  },
  {
    id: 'ex-egyptian-cable-lateral-raise',
    name: 'Elevação Lateral Egípcia Inclinada na Polia (Egyptian Lateral Raise)',
    target_muscle: 'shoulders',
    secondary_muscles: [],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Segure no poste do cabo com uma mão e incline o corpo a cerca de 20° para fora.',
      'Puxe o cabo com a mão externa elevando lateralmente até a altura do ombro.',
      'A inclinação do corpo aumenta a tensão no ponto mais encurtado do músculo.',
    ],
  },
  {
    id: 'ex-seated-dumbbell-lateral-raise',
    name: 'Elevação Lateral Sentado no Banco Reto com Halteres',
    target_muscle: 'shoulders',
    secondary_muscles: [],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Sentado na ponta do banco, eliminando completamente qualquer impulso do quadril e pernas.',
      'Suba com os cotovelos guiando o movimento em arco limpo.',
    ],
  },
  {
    id: 'ex-chest-supported-rear-delt-row',
    name: 'Remada Aberta Apoiada no Peito para Deltoide Posterior (Chest-Supported Rear Delt Row)',
    target_muscle: 'shoulders',
    secondary_muscles: ['back'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Deite de bruços no banco inclinado a 30°-45° com halteres.',
      'Puxe com os cotovelos bem abertos a 80°-90° do tronco para isolar o deltoide posterior sem foco em dorsal.',
    ],
  },
  {
    id: 'ex-face-pull-external-rotation',
    name: 'Face Pull na Polia Alta com Rotação Externa e Pico de Contração',
    target_muscle: 'shoulders',
    secondary_muscles: ['back'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Polia na altura dos olhos ou acima com corda. Puxe a corda em direção à testa.',
      'Ao final do movimento, gire os polegares para trás realizando rotação externa completa dos ombros por 1-2 segundos.',
    ],
  },
  {
    id: 'ex-landmine-overhead-press',
    name: 'Desenvolvimento Landmine Unilateral em Pé com Barra (Landmine Press)',
    target_muscle: 'shoulders',
    secondary_muscles: ['triceps', 'core'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Barra apoiada no acessório Landmine ou canto. Segure a ponta com uma mão junto ao ombro.',
      'Empurre na diagonal para cima com estabilidade do core, excelente para quem tem dores com desenvolvimento vertical rígido.',
    ],
  },
  {
    id: 'ex-bayesian-cable-curl',
    name: 'Rosca Bayesian no Cabo (Polia por Trás das Costas com Extensão de Ombro)',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Posicione a polia baixa, segure a manopla de costas para o aparelho e dê dois passos à frente.',
      'O braço fica posicionado atrás do tronco em extensão de ombro, colocando a cabeça longa do bíceps sob estiramento máximo.',
      'Flexione o cotovelo mantendo a parte superior do braço estável.',
    ],
  },
  {
    id: 'ex-behind-back-cable-curl',
    name: 'Rosca Bíceps na Polia Baixa por Trás do Tronco (Single-Arm Cable Curl)',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Mesmo padrão biomecânico da rosca inclinada, mas com curva de resistência constante oferecida pelo cabo.',
    ],
  },
  {
    id: 'ex-cross-body-hammer-curl',
    name: 'Rosca Martelo Cruzada no Peito com Halteres (Braquial & Braquiorradial)',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Segure os halteres com pegada neutra. Flexione o cotovelo cruzando o halter na frente do peitoral em direção ao ombro oposto.',
      'Enfatiza intensamente o músculo braquial profundo, alargando a espessura do braço.',
    ],
  },
  {
    id: 'ex-rope-cable-hammer-curl',
    name: 'Rosca Martelo na Polia Baixa com Corda (Cable Rope Hammer Curl)',
    target_muscle: 'biceps',
    secondary_muscles: ['forearms'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Com pegada neutra nas pontas da corda, puxe abrindo levemente as mãos no topo da contração.',
    ],
  },
  {
    id: 'ex-katana-triceps-extension',
    name: 'Extensão de Tríceps Katana Bilateral na Polia Alta (Katana Triceps Extension)',
    target_muscle: 'triceps',
    secondary_muscles: [],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Polias ajustadas na altura dos ombros. Cruze os cabos e segure a manopla direita com a mão esquerda e vice-versa.',
      'Posicione os braços acima da cabeça em formato de "espadas katana". Estenda os cotovelos em diagonal para fora.',
      'Coloca a cabeça longa do tríceps em estiramento hipertrófico extremo com perfil de resistência uniforme.',
    ],
  },
  {
    id: 'ex-single-arm-cross-cable-triceps',
    name: 'Extensão de Tríceps Cruzada Unilateral na Polia (Cross-Body Cable Extension)',
    target_muscle: 'triceps',
    secondary_muscles: [],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Polia alta sem pegador (segurando na bolinha do cabo). Braço cruzado na frente do peito.',
      'Estenda o cotovelo empurrando em diagonal para baixo e para o lado com isolamento absoluto.',
    ],
  },
  {
    id: 'ex-jm-press-barbell',
    name: 'JM Press com Barra Olímpica (Híbrido Supino Fechado e Tríceps Testa)',
    target_muscle: 'triceps',
    secondary_muscles: ['chest', 'shoulders'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Deitado no supino com pegada na largura dos ombros. Desça a barra em direção ao pescoço/clavícula dobrando os cotovelos para frente.',
      'Pare a 5-10cm da garganta e empurre estendendo os tríceps com enorme sobrecarga mecânica.',
    ],
  },
  {
    id: 'ex-overhead-cable-rope-triceps',
    name: 'Tríceps Francês na Polia Alta com Corda e Afastamento (Overhead Cable Extension)',
    target_muscle: 'triceps',
    secondary_muscles: [],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'De costas para a polia alta, dê um passo à frente com tronco inclinado a 45° segurando a corda por trás da cabeça.',
      'Estenda os cotovelos para a frente abrindo a corda no final para pico de contração na cabeça longa.',
    ],
  },
  {
    id: 'ex-high-bar-box-squat',
    name: 'Agachamento no Caixote com Barra Alta (High-Bar Box Squat)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes', 'hamstrings', 'core'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Posicione um caixote ou banco na altura paralela atrás de você.',
      'Desça de forma controlada até sentar brevemente sem relaxar o tronco ou perder a tensão espinhal.',
      'Exploda para cima a partir da inércia, ensinando profundidade rigorosa e quebrando reflexo miotático.',
    ],
  },
  {
    id: 'ex-low-bar-back-squat',
    name: 'Agachamento Livre com Barra Baixa Powerlifting (Low-Bar Squat)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes', 'hamstrings', 'back', 'core'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Posicione a barra sobre os deltoides posteriores com tronco mais inclinado à frente.',
      'Maior recrutamento de glúteos e cadeia posterior permitindo movimentar cargas máximas.',
    ],
  },
  {
    id: 'ex-reverse-hack-squat',
    name: 'Agachamento Hack Invertido na Máquina (Reverse Hack Squat para Glúteos & Posterior)',
    target_muscle: 'glutes',
    secondary_muscles: ['hamstrings', 'quadriceps'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Posicione-se de frente para a almofada do Hack Squat com os pés na plataforma.',
      'Agache projetando o quadril para trás, permitindo flexão profunda de quadril com ênfase em glúteo máximo.',
    ],
  },
  {
    id: 'ex-reverse-nordic-curl',
    name: 'Flexão Nórdica Reversa no Solo (Reverse Nordic Curl para Reto Femoral)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['core'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Ajoelhe-se em um colchonete com tronco reto e quadril totalmente estendido.',
      'Incline o corpo reto para trás a partir dos joelhos até sentir estiramento absurdo nos quadríceps, especialmente reto femoral.',
      'Retorne puxando com a força dos quadríceps.',
    ],
  },
  {
    id: 'ex-swiss-ball-leg-curl',
    name: 'Flexão de Joelhos na Bola Suíça (Swiss Ball Hamstring Curl)',
    target_muscle: 'hamstrings',
    secondary_muscles: ['glutes', 'core'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Deite no solo com os calcanhares apoiados sobre a bola suíça e eleve o quadril.',
      'Puxe a bola em direção aos glúteos flexionando os joelhos e mantendo o quadril alto.',
    ],
  },
  {
    id: 'ex-single-leg-rdl-dumbbell',
    name: 'Levantamento Terra Romeno Unilateral com Halter (Single-Leg RDL)',
    target_muscle: 'hamstrings',
    secondary_muscles: ['glutes', 'core'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Equilibre-se em uma perna segurando um halter na mão oposta.',
      'Projete o tronco à frente e a perna livre para trás como uma gangorra mantendo coluna alinhada.',
      'Estiramento unilateral cirúrgico e correção de assimetrias nos posteriores de coxa.',
    ],
  },
  {
    id: 'ex-trap-bar-deadlift',
    name: 'Levantamento Terra com Barra Hexagonal (Trap Bar / Hex Bar Deadlift)',
    target_muscle: 'back',
    secondary_muscles: ['quadriceps', 'glutes', 'hamstrings', 'forearms'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Posicione-se no centro da barra hexagonal com pegada neutra confortável.',
      'O centro de gravidade alinhado reduz significativamente o cisalhamento na lombar e distribui o esforço entre quadríceps, glúteos e dorsais.',
    ],
  },
  {
    id: 'ex-deficit-deadlift',
    name: 'Levantamento Terra com Déficit de 5cm sobre Plataforma (Deficit Deadlift)',
    target_muscle: 'back',
    secondary_muscles: ['hamstrings', 'glutes', 'quadriceps'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Fique em cima de uma anilha ou bloco de 3 a 5cm de altura.',
      'Aumenta a amplitude na saída do solo, exigindo máxima potência inicial de pernas e dorsais.',
    ],
  },
  {
    id: 'ex-snatch-grip-deadlift',
    name: 'Levantamento Terra com Pegada Aberta de Arranco (Snatch-Grip Deadlift)',
    target_muscle: 'back',
    secondary_muscles: ['hamstrings', 'glutes'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Segure a barra com pegada bem afastada próxima aos anéis externos.',
      'Exige descida mais funda do quadril e ativação massiva de toda a musculatura do trapézio e meio das costas.',
    ],
  },
  {
    id: 'ex-cable-pull-through',
    name: 'Puxada de Quadril na Polia entre as Pernas (Cable Pull-Through)',
    target_muscle: 'glutes',
    secondary_muscles: ['hamstrings', 'core'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'De costas para a polia baixa, segure a corda passando-a por entre as pernas e dê um passo à frente.',
      'Flexione o quadril empurrando os glúteos para trás com joelhos semi-flexionados.',
      'Estenda o quadril com força e contraia os glúteos no topo.',
    ],
  },
  {
    id: 'ex-neutral-grip-lat-pulldown',
    name: 'Puxada Alta com Pegada Neutra Fechada (Mag Grip / Triângulo)',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'forearms'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Puxe com pegada neutra direcionando os cotovelos para baixo e para frente junto às costelas.',
      'Excelente alinhamento anatômico com as fibras verticais do grande dorsal com menor estresse no punho e ombro.',
    ],
  },
  {
    id: 'ex-half-kneeling-lat-pulldown',
    name: 'Puxada Unilateral Semi-Ajoelhado na Polia (Half-Kneeling Lat Pulldown)',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'core'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Ajoelhe-se em uma perna em frente ao cabo alto.',
      'Puxe a manopla focando na compressão do cotovelo em direção ao quadril, mantendo a coluna alinhada.',
    ],
  },
  {
    id: 'ex-omni-grip-pull-up',
    name: 'Barra Fixa Multi-Pegada (Omni-Grip Pull-Up: Pronada, Neutra e Supinada)',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'forearms', 'core'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Varie a pegada entre séries (aberta pronada, neutra fechada e supinada).',
      'Puxe o peitoral até a barra mantendo escápulas ativadas e evitando balanço.',
    ],
  },
  {
    id: 'ex-chest-supported-t-bar-row',
    name: 'Remada Cavalinho Articulada com Apoio no Peito (T-Bar Row)',
    target_muscle: 'back',
    secondary_muscles: ['biceps'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Peito totalmente apoiado na almofada inclinada, tirando toda a carga da região lombar.',
      'Puxe os cotovelos para trás apertando as escápulas com máxima amplitude.',
    ],
  },
  {
    id: 'ex-helms-row-incline',
    name: 'Remada Helms com Halteres no Banco Inclinado 45° (Helms Row)',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'shoulders'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Apoie a parte superior do tórax na borda de um banco inclinado a 45° com as pernas firmes no chão.',
      'Remada estrita com halteres onde você não consegue roubar com balanço do corpo.',
    ],
  },
  {
    id: 'ex-kelso-shrug-bench',
    name: 'Encolhimento Kelso com Halteres no Banco Inclinado (Trapézio Médio & Romboides)',
    target_muscle: 'back',
    secondary_muscles: ['shoulders'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Deite de bruços no banco inclinado. Braços estendidos segurando halteres.',
      'Mantenha os cotovelos retos e execute apenas a retração pura das escápulas, juntando-as no topo por 2 segundos.',
    ],
  },
  {
    id: 'ex-seal-row-bench',
    name: 'Remada Seal no Banco Reto Elevado com Barra (Seal Row)',
    target_muscle: 'back',
    secondary_muscles: ['biceps'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Deite totalmente na horizontal de bruços sobre um banco elevado especial.',
      'Puxe a barra até encostar na parte inferior do banco sem qualquer impulso lombar.',
    ],
  },
  {
    id: 'ex-meadows-row-landmine',
    name: 'Remada Meadows com Barra no Landmine (Pegada na Ponta)',
    target_muscle: 'back',
    secondary_muscles: ['biceps', 'forearms'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Fique de pé perpendicular à ponta de uma barra no landmine.',
      'Segure na ponta com pegada pronada (use straps se necessário) e puxe o cotovelo para cima e para fora.',
      'Exercício clássico criado por John Meadows para espessura absurda do grande dorsal e redondo maior.',
    ],
  },
  {
    id: 'ex-cross-body-rear-delt-cable',
    name: 'Crucifixo Invertido Cruzado na Polia Dupla (Rear Delt Cable Fly)',
    target_muscle: 'shoulders',
    secondary_muscles: ['back'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Cruze os cabos nas polias ajustadas na altura dos ombros.',
      'Abra os braços para os lados mantendo leve flexão dos cotovelos, focando exclusivamente no deltoide posterior.',
    ],
  },
  {
    id: 'ex-smith-bulgarian-split-squat',
    name: 'Agachamento Búlgaro no Smith Machine com Step (Smith Bulgarian Split Squat)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes', 'hamstrings'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pé de trás apoiado no banco e pé da frente no chão ou sobre um pequeno step para maior profundidade.',
      'A barra fixa do Smith permite focar 100% na queima muscular sem se preocupar com o equilíbrio lateral.',
    ],
  },
  {
    id: 'ex-walking-lunges-heavy',
    name: 'Passada Caminhando com Halteres Pesados (Walking Lunges)',
    target_muscle: 'quadriceps',
    secondary_muscles: ['glutes', 'hamstrings', 'calves'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Dê passos longos controlados descendo o joelho de trás até quase tocar o solo.',
      'Mantenha o tronco firme e impulsione com o calcanhar da perna da frente.',
    ],
  },
  {
    id: 'ex-barbell-hip-thrust-heavy',
    name: 'Elevação Pélvica com Barra Olímpica e Apoio Escapular (Hip Thrust)',
    target_muscle: 'glutes',
    secondary_muscles: ['hamstrings', 'core'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Escápulas firmes no banco, barra acolchoada sobre a linha do quadril e pés na largura dos ombros.',
      'Empurre o chão com os calcanhares estendendo totalmente o quadril e segure 1 segundo no topo com queixo recolhido.',
    ],
  },
  {
    id: 'ex-machine-hip-thrust-plate',
    name: 'Elevação Pélvica Articulada na Máquina com Anilha (Plate-Loaded Hip Thrust)',
    target_muscle: 'glutes',
    secondary_muscles: ['hamstrings'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Facilidade de montagem com cinto acolchoado reforçado e trava de segurança.',
      'Contração de glúteos consistente sem esmagamento do osso ilíaco.',
    ],
  },
  {
    id: 'ex-seated-calf-raise-soleus',
    name: 'Elevação de Panturrilha Sentado na Máquina para Sóleo (Seated Calf Raise)',
    target_muscle: 'calves',
    secondary_muscles: [],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Joelhos flexionados a 90° desativam os gastrocnêmios e focam diretamente no músculo sóleo.',
      'Desça até o alongamento máximo do tendão calcâneo e pause antes de subir.',
    ],
  },
  {
    id: 'ex-donkey-calf-raise-machine',
    name: 'Elevação Burrinho de Panturrilha na Máquina ou com Apoio (Donkey Calf Raise)',
    target_muscle: 'calves',
    secondary_muscles: ['hamstrings'],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Tronco inclinado a 90° em flexão de quadril com pernas retas.',
      'Alongamento biomecânico superior para os gastrocnêmios mediais e laterais.',
    ],
  },
  {
    id: 'ex-leg-press-calf-raise-45',
    name: 'Panturrilha no Leg Press 45° com Pés no Limiar da Plataforma',
    target_muscle: 'calves',
    secondary_muscles: [],
    category: 'machine',
    thumbnail_url: 'https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Apenas as pontas dos pés no limite inferior da plataforma com joelhos em microflexão segura.',
      'Estenda os tornozelos empurrando o carrinho e desça em amplitude completa controlada.',
    ],
  },
  {
    id: 'ex-kneeling-cable-crunch',
    name: 'Abdominal Crunch Ajoelhado na Polia Alta com Corda (Cable Crunch)',
    target_muscle: 'core',
    secondary_muscles: [],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Ajoelhado em frente à polia segurando as pontas da corda ao lado das orelhas.',
      'Enrole a coluna trazendo a caixa torácica em direção à pelve sem sentar nos calcanhares.',
    ],
  },
  {
    id: 'ex-hanging-leg-raise-weighted',
    name: 'Elevação de Pernas Completa Suspenso na Barra Fixa com Carga',
    target_muscle: 'core',
    secondary_muscles: ['forearms'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Pendurado na barra, eleve os pés até a altura do rosto ou barra.',
      'Certifique-se de realizar retroversão pélvica para ativar o abdômen e não apenas os flexores de quadril.',
    ],
  },
  {
    id: 'ex-roman-chair-leg-raise',
    name: 'Elevação de Pernas na Cadeira Romana / Cadeira do Capitão',
    target_muscle: 'core',
    secondary_muscles: [],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Apoie os cotovelos nas almofadas com costas bem apoiadas.',
      'Eleve as pernas estendidas ou joelhos flexionados enrolando o quadril.',
    ],
  },
  {
    id: 'ex-ab-wheel-rollout-strict',
    name: 'Roda Abdominal no Solo com Extensão Completa (Ab Wheel Rollout)',
    target_muscle: 'core',
    secondary_muscles: ['shoulders', 'back'],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Ajoelhado, role a roda para a frente estendendo o corpo quase até o chão mantendo o abdômen contraído em prancha oca.',
      'Puxe de volta flexionando o core sem usar a força dos braços.',
    ],
  },
  {
    id: 'ex-pallof-press-cable',
    name: 'Pallof Press na Polia com Pausa Isométrica (Anti-Rotação de Core)',
    target_muscle: 'core',
    secondary_muscles: ['chest', 'shoulders'],
    category: 'cable',
    thumbnail_url: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'De lado para a polia média segurando a manopla no centro do peito.',
      'Estenda os braços à frente resistindo à rotação do cabo por 2-3 segundos e retorne ao peito.',
    ],
  },
  {
    id: 'ex-decline-weighted-crunch',
    name: 'Abdominal no Banco Declinado com Anilha no Peito (Decline Crunch)',
    target_muscle: 'core',
    secondary_muscles: [],
    category: 'bodyweight',
    thumbnail_url: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Prenda os pés no banco declinado e segure uma anilha contra o peitoral.',
      'Suba enrolando a coluna e descendo devagar sem relaxar no fundo.',
    ],
  },
  {
    id: 'ex-farmer-walk-suitcase',
    name: 'Caminhada da Mala Unilateral com Halter Pesado (Suitcase Carry)',
    target_muscle: 'forearms',
    secondary_muscles: ['core', 'back'],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Segure um halter pesado em apenas um dos lados do corpo.',
      'Caminhe em passos firmes mantendo o tronco rigorosamente ereto sem inclinar para o lado do peso.',
      'Força absurda de antebraço, pegada e músculos oblíquos estabilizadores.',
    ],
  },
  {
    id: 'ex-plate-pinch-grip',
    name: 'Sustentação em Pinça de Duas Anilhas Lisas (Plate Pinch Grip)',
    target_muscle: 'forearms',
    secondary_muscles: [],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Junte duas anilhas de 5kg ou 10kg com os lados lisos para fora.',
      'Segure-as apenas com as pontas dos dedos e polegar em pinça isométrica por 20 a 40 segundos.',
    ],
  },
  {
    id: 'ex-wrist-roller-forearm',
    name: 'Rolo de Punho com Corda e Anilha para Antebraço (Wrist Roller)',
    target_muscle: 'forearms',
    secondary_muscles: ['shoulders'],
    category: 'barbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Segure o rolo com braços estendidos ou apoiados.',
      'Enrole a corda girando os punhos para cima até a anilha subir e depois desenrole com controle total.',
    ],
  },
  {
    id: 'ex-seated-wrist-curl-dumbbell',
    name: 'Rosca Punho Sentado no Banco com Halteres (Flexores de Punho)',
    target_muscle: 'forearms',
    secondary_muscles: [],
    category: 'dumbbell',
    thumbnail_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&auto=format&fit=crop&q=80',
    instructions: [
      'Antebraços apoiados nas coxas com punhos para fora dos joelhos.',
      'Flexione os punhos para cima levantando os halteres e desça abrindo levemente os dedos.',
    ],
  },
];

