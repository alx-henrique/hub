import React, { useState, useEffect } from 'react';
import {
  WorkoutPlan,
  WorkoutPlanDay,
  WorkoutSession,
  BodyMeasurement,
  MuscleGroup,
  MUSCLE_LABELS,
  Exercise,
} from './features/fitness/types';
import { FitnessStorageService } from './features/fitness/services/storageService';
import { DigitalMannequin } from './features/fitness/components/DigitalMannequin';
import { ConsistencyHeatmap } from './features/fitness/components/ConsistencyHeatmap';
import { VolumeProgressionChart } from './features/fitness/components/VolumeProgressionChart';
import { WorkoutLoggerModal } from './features/fitness/components/WorkoutLoggerModal';
import { WorkoutPlanManager } from './features/fitness/components/WorkoutPlanManager';
import { AICoachPanel } from './features/fitness/components/AICoachPanel';
import { DatabaseSchemaModal } from './features/fitness/components/DatabaseSchemaModal';
import { ExerciseExecutionModal } from './features/fitness/components/ExerciseExecutionModal';
import { ExerciseVectorIllustration } from './features/fitness/components/ExerciseVectorIllustration';
import { calculateVolumeLoad } from './features/fitness/utils/progressionLogic';
import {
  Activity,
  Dumbbell,
  Brain,
  Database,
  Play,
  RotateCcw,
  Sparkles,
  Trophy,
  Flame,
  Search,
  BookOpen,
  Info,
  CheckCircle2,
  Calendar,
  Layers,
  Plus,
  X,
  ExternalLink,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';

type QuickCategory =
  | 'all'
  | 'hypertrophy'
  | 'deadlifts'
  | 'chest'
  | 'back'
  | 'legs'
  | 'shoulders'
  | 'arms'
  | 'core';

export default function App() {
  const [plans, setPlans] = useState<WorkoutPlan[]>(() => FitnessStorageService.getPlans());
  const [sessions, setSessions] = useState<WorkoutSession[]>(() => FitnessStorageService.getSessions());
  const [measurements, setMeasurements] = useState<BodyMeasurement[]>(() =>
    FitnessStorageService.getMeasurements()
  );

  // Navegação: 'workout' | 'analytics' | 'plans' | 'exercises' | 'coach'
  const [activeTab, setActiveTab] = useState<'workout' | 'analytics' | 'plans' | 'exercises' | 'coach'>('workout');
  const [selectedDayId, setSelectedDayId] = useState<string>('');

  // Músculo selecionado no Manequim Digital
  const [selectedMuscle, setSelectedMuscle] = useState<MuscleGroup | null>('back');

  // Modal de treino ativo
  const [activeWorkoutDay, setActiveWorkoutDay] = useState<WorkoutPlanDay | null>(null);

  // Modal de celebração de treino recém-concluído
  const [completedCelebrationSession, setCompletedCelebrationSession] = useState<WorkoutSession | null>(null);

  // Modal de Schema do Banco de Dados
  const [isSchemaModalOpen, setIsSchemaModalOpen] = useState(false);

  // Filtros de Exercícios no Catálogo
  const [exerciseCatalogSearch, setExerciseCatalogSearch] = useState('');
  const [catalogCategory, setCatalogCategory] = useState<QuickCategory>('all');
  const [exerciseCatalogEquipment, setExerciseCatalogEquipment] = useState<string | 'all'>('all');
  const [allExercises, setAllExercises] = useState<Exercise[]>(() => FitnessStorageService.getAllExercises());

  // Modal de inclusão de exercício direto na ficha
  const [exerciseToAddToPlan, setExerciseToAddToPlan] = useState<Exercise | null>(null);
  const [targetPlanDayId, setTargetPlanDayId] = useState<string>('');

  // Modal de execução/teste individual do exercício (IMG_5893)
  const [executingExercise, setExecutingExercise] = useState<Exercise | null>(null);

  // Formulário de exercício personalizado
  const [isCreateCustomOpen, setIsCreateCustomOpen] = useState(false);
  const [customExerciseForm, setCustomExerciseForm] = useState({
    name: '',
    target_muscle: 'back' as MuscleGroup,
    category: 'barbell' as Exercise['category'],
    instructions: '',
  });

  // Cálculo das pontuações musculares atualizadas para o Manequim Digital
  const muscleScores = FitnessStorageService.calculateMuscleScores();

  // Salvar novos planos
  const handleSavePlans = (updated: WorkoutPlan[]) => {
    setPlans(updated);
    FitnessStorageService.savePlans(updated);
  };

  // Finalizar sessão de treino
  const handleSessionCompleted = (newSession: WorkoutSession) => {
    const updated = FitnessStorageService.addSession(newSession);
    setSessions(updated);
    setActiveWorkoutDay(null);
    setCompletedCelebrationSession(newSession);
  };

  // Adicionar nova medida corporal
  const handleAddMeasurement = (newMeas: BodyMeasurement) => {
    const updated = FitnessStorageService.addMeasurement(newMeas);
    setMeasurements(updated);
  };

  // Criar exercício personalizado
  const handleCreateCustomExercise = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customExerciseForm.name.trim()) return;

    const newEx: Exercise = {
      id: `custom-${Date.now()}`,
      name: customExerciseForm.name.trim(),
      target_muscle: customExerciseForm.target_muscle,
      secondary_muscles: [],
      category: customExerciseForm.category,
      instructions: customExerciseForm.instructions
        ? customExerciseForm.instructions.split('\n').filter(Boolean)
        : ['Movimento registrado pelo usuário.'],
      thumbnail_url: '',
      is_custom: true,
    };

    FitnessStorageService.addCustomExercise(newEx);
    setAllExercises(FitnessStorageService.getAllExercises());
    setIsCreateCustomOpen(false);
    setCustomExerciseForm({
      name: '',
      target_muscle: 'back',
      category: 'barbell',
      instructions: '',
    });
  };

  // Adicionar exercício selecionado da biblioteca direto a um dia da ficha
  const handleConfirmAddExerciseToPlan = () => {
    if (!exerciseToAddToPlan || !targetPlanDayId) return;

    const currentActivePlan = plans.find((p) => p.is_active) || plans[0];
    if (!currentActivePlan) return;

    const updatedDays = currentActivePlan.days.map((day) => {
      if (day.id === targetPlanDayId) {
        return {
          ...day,
          exercises: [
            ...day.exercises,
            {
              id: `pe-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
              exercise_id: exerciseToAddToPlan.id,
              exercise: exerciseToAddToPlan,
              target_sets: 4,
              min_reps: exerciseToAddToPlan.id.includes('deadlift') ? 6 : 8,
              max_reps: exerciseToAddToPlan.id.includes('deadlift') ? 8 : 12,
              order_index: day.exercises.length,
              rest_seconds: exerciseToAddToPlan.id.includes('deadlift') ? 120 : 75,
            },
          ],
        };
      }
      return day;
    });

    const updatedPlan: WorkoutPlan = {
      ...currentActivePlan,
      days: updatedDays,
    };

    const updatedPlans = plans.map((p) => (p.id === currentActivePlan.id ? updatedPlan : p));
    handleSavePlans(updatedPlans);
    setExerciseToAddToPlan(null);
    setTargetPlanDayId('');
  };

  // Resetar dados para o padrão de demonstração
  const handleResetData = () => {
    if (window.confirm('Deseja recarregar a base com as fichas atualizadas de Levantamento Terra e dados oficiais?')) {
      FitnessStorageService.resetToDefault();
      setPlans(FitnessStorageService.getPlans());
      setSessions(FitnessStorageService.getSessions());
      setMeasurements(FitnessStorageService.getMeasurements());
      setAllExercises(FitnessStorageService.getAllExercises());
    }
  };

  const activePlan = plans.find((p) => p.is_active) || plans[0];
  const currentTrainingDay =
    (selectedDayId && activePlan?.days.find((d) => d.id === selectedDayId)) ||
    activePlan?.days[0];

  // Cálculo de KPIs para o cabeçalho moderno
  const totalVolume30d = sessions.reduce((acc, sess) => {
    const sets = Object.values(sess.exercises_logs || {}).flat();
    return acc + calculateVolumeLoad(sets.filter((s) => s.completed));
  }, 0);

  // Recordes Pessoais (PRs) dos Grandes Levantamentos
  const personalRecords = React.useMemo(() => {
    const keyExercises = [
      { id: 'ex-deadlift-conventional', name: 'Levantamento Terra', target: 'Lombar & Costas', defaultMax: 150, defaultReps: 6, default1RM: 180 },
      { id: 'ex-bench-press', name: 'Supino Reto', target: 'Peitoral & Tríceps', defaultMax: 105, defaultReps: 8, default1RM: 133 },
      { id: 'ex-barbell-squat', name: 'Agachamento Livre', target: 'Quadríceps & Glúteos', defaultMax: 130, defaultReps: 6, default1RM: 156 },
      { id: 'ex-overhead-press', name: 'Desenvolvimento Militar', target: 'Ombros & Deltóides', defaultMax: 65, defaultReps: 8, default1RM: 82 },
    ];

    return keyExercises.map((ke) => {
      let maxWeight = 0;
      let bestReps = 0;
      let best1RM = 0;
      let lastDate = '';

      sessions.forEach((s) => {
        const sets = s.exercises_logs?.[ke.id];
        if (sets && sets.length > 0) {
          sets.forEach((set) => {
            if (set.completed && set.weight_kg > 0) {
              const e1rm = Math.round(set.weight_kg * (1 + (set.reps_performed || 1) / 30));
              if (e1rm > best1RM || set.weight_kg > maxWeight) {
                best1RM = Math.max(best1RM, e1rm);
                maxWeight = Math.max(maxWeight, set.weight_kg);
                bestReps = set.reps_performed;
                lastDate = s.started_at;
              }
            }
          });
        }
      });

      if (maxWeight === 0) {
        maxWeight = ke.defaultMax;
        bestReps = ke.defaultReps;
        best1RM = ke.default1RM;
      }

      return {
        ...ke,
        maxWeight,
        bestReps,
        best1RM,
        lastDate: lastDate ? new Date(lastDate).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }) : 'Ciclo atual',
      };
    });
  }, [sessions]);

  // Filtragem dinâmica dos exercícios
  const filteredExercises = allExercises.filter((ex) => {
    const s = exerciseCatalogSearch.toLowerCase().trim();
    const matchesSearch =
      !s ||
      ex.name.toLowerCase().includes(s) ||
      (ex.target_muscle && MUSCLE_LABELS[ex.target_muscle]?.toLowerCase().includes(s));

    let matchesCategory = true;
    if (catalogCategory === 'hypertrophy') {
      matchesCategory =
        ex.id.includes('incline') ||
        ex.id.includes('bayesian') ||
        ex.id.includes('katana') ||
        ex.id.includes('jm-press') ||
        ex.id.includes('helms') ||
        ex.id.includes('kelso') ||
        ex.id.includes('meadows') ||
        ex.id.includes('constant-tension') ||
        ex.id.includes('box-squat') ||
        ex.id.includes('nordic') ||
        ex.id.includes('cross-body') ||
        ex.id.includes('seal-row') ||
        ex.id.includes('spoto') ||
        ex.id.includes('y-raise') ||
        ex.id.includes('trap-bar') ||
        ex.id.includes('deficit') ||
        ex.id.includes('bulgarian') ||
        ex.id.includes('pull-through') ||
        ex.name.toLowerCase().includes('inclinado') ||
        ex.name.toLowerCase().includes('t-bar') ||
        ex.name.toLowerCase().includes('bayesian') ||
        ex.name.toLowerCase().includes('katana') ||
        ex.name.toLowerCase().includes('smith') ||
        ex.name.toLowerCase().includes('cavalinho') ||
        ex.name.toLowerCase().includes('convergente');
    } else if (catalogCategory === 'deadlifts') {
      matchesCategory =
        ex.id.includes('deadlift') ||
        ex.id.includes('stiff') ||
        ex.id.includes('good-morning') ||
        ex.name.toLowerCase().includes('terra') ||
        ex.name.toLowerCase().includes('rdl') ||
        ex.name.toLowerCase().includes('stiff');
    } else if (catalogCategory === 'chest') {
      matchesCategory = ex.target_muscle === 'chest';
    } else if (catalogCategory === 'back') {
      matchesCategory = ex.target_muscle === 'back';
    } else if (catalogCategory === 'legs') {
      matchesCategory = ['quadriceps', 'hamstrings', 'calves', 'glutes'].includes(ex.target_muscle);
    } else if (catalogCategory === 'shoulders') {
      matchesCategory = ex.target_muscle === 'shoulders';
    } else if (catalogCategory === 'arms') {
      matchesCategory = ['biceps', 'triceps', 'forearms'].includes(ex.target_muscle);
    } else if (catalogCategory === 'core') {
      matchesCategory = ex.target_muscle === 'core';
    }

    const matchesEquipment =
      exerciseCatalogEquipment === 'all' || ex.category === exerciseCatalogEquipment;

    return matchesSearch && matchesCategory && matchesEquipment;
  });

  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-100 flex flex-col font-sans pb-28 selection:bg-zinc-200 selection:text-zinc-900">
      {/* HEADER PRINCIPAL - KINETIC */}
      <header className="sticky top-0 z-40 bg-[#09090b]/95 backdrop-blur-xl border-b border-zinc-800/80 px-4 py-3 sm:px-6">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
          {/* LOGO & BRAND */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 rounded-xl bg-white text-zinc-950 font-black text-sm tracking-tighter flex items-center justify-center shadow-sm">
              K
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-bold text-white tracking-tight">
                  KINETIC
                </h1>
                <span className="text-[10px] font-medium uppercase px-2 py-0.5 rounded-md bg-zinc-800/90 text-zinc-300 border border-zinc-700/60 hidden sm:inline-block">
                  Diário de Treino
                </span>
              </div>
              <p className="text-[11px] text-zinc-400">
                Hipertrofia & Sobrecarga Progressiva
              </p>
            </div>
          </div>

          {/* NAVEGAÇÃO DESKTOP / TABLET (SEGMENTED TABS) */}
          <nav className="hidden md:flex items-center gap-1 p-1 bg-zinc-900/90 border border-zinc-800/80 rounded-xl">
            <button
              type="button"
              onClick={() => setActiveTab('workout')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                activeTab === 'workout'
                  ? 'bg-zinc-800 text-white font-semibold shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Treino de Hoje
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('analytics')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                activeTab === 'analytics'
                  ? 'bg-zinc-800 text-white font-semibold shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Bio-Feedback & Análise
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('plans')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                activeTab === 'plans'
                  ? 'bg-zinc-800 text-white font-semibold shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Fichas de Treino
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('exercises')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                activeTab === 'exercises'
                  ? 'bg-zinc-800 text-white font-semibold shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Biblioteca ({allExercises.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('coach')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                activeTab === 'coach'
                  ? 'bg-zinc-800 text-white font-semibold shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              AI Coach
            </button>
          </nav>

          {/* AÇÕES DE UTILITÁRIOS */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setIsSchemaModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs font-medium text-zinc-300 transition-all cursor-pointer"
              title="Ver Schema SQL Supabase"
            >
              <Database className="w-3.5 h-3.5 text-zinc-400" />
              <span className="hidden sm:inline">SQL Supabase</span>
            </button>

            <button
              type="button"
              onClick={handleResetData}
              className="p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white transition-all cursor-pointer"
              title="Restaurar dados iniciais completos"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </header>

      {/* PAINEL INTEGRADO DE TELEMETRIA ATLÉTICA */}
      <section className="bg-zinc-950 border-b border-zinc-800/80 px-4 py-3">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-y-2 gap-x-6 text-xs">
          <div className="flex items-center gap-2.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
            <span className="text-zinc-400">Ficha Ativa:</span>
            <span className="font-semibold text-white truncate max-w-[220px]">
              {activePlan?.title || 'Hipertrofia ABC'}
            </span>
          </div>

          <div className="flex items-center gap-6 divide-x divide-zinc-800">
            <div className="flex items-center gap-2">
              <span className="text-[11px] uppercase tracking-wider text-zinc-400">Volume 30d</span>
              <span className="font-mono font-bold text-white">
                {totalVolume30d.toLocaleString('pt-BR')} kg
              </span>
            </div>

            <div className="pl-6 flex items-center gap-2">
              <span className="text-[11px] uppercase tracking-wider text-zinc-400">Consistência</span>
              <span className="font-mono font-bold text-white">
                12 sessões
              </span>
            </div>

            <div className="pl-6 hidden sm:flex items-center gap-2">
              <span className="text-[11px] uppercase tracking-wider text-zinc-400">Exercícios</span>
              <span className="font-mono font-bold text-white">
                {allExercises.length}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* CONTEÚDO PRINCIPAL COM ABAS */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 sm:p-6 space-y-6">
        {/* ========================================================================= */}
        {/* ABA 1: TREINO DE HOJE (ROSTER COMPLETO & EXECUÇÃO)                        */}
        {/* ========================================================================= */}
        {activeTab === 'workout' && currentTrainingDay && (
          <div className="space-y-6 animate-fade-in">
            {/* HERO PRINCIPAL DO TREINO ATIVO */}
            <div className="bg-zinc-900/90 border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-sm relative overflow-hidden">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                <div className="space-y-4 max-w-2xl">
                  {/* Seletor de Divisões da Ficha Ativa */}
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-zinc-500 mr-1 shrink-0">
                      Divisões:
                    </span>
                    {activePlan?.days.map((day, dIdx) => {
                      const isCurrent = currentTrainingDay.id === day.id;
                      return (
                        <button
                          key={day.id}
                          type="button"
                          onClick={() => setSelectedDayId(day.id)}
                          className={`px-3.5 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                            isCurrent
                              ? 'bg-white text-zinc-950 font-bold shadow-sm'
                              : 'bg-zinc-950 text-zinc-400 border border-zinc-800 hover:text-white hover:border-zinc-700'
                          }`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${isCurrent ? 'bg-zinc-950' : 'bg-zinc-600'}`} />
                          {day.day_name}
                        </button>
                      );
                    })}
                  </div>

                  <div>
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="px-2.5 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-zinc-800 text-zinc-300 border border-zinc-700/60">
                        {activePlan?.title || 'Ficha Ativa'}
                      </span>
                      <span className="text-xs text-zinc-400 font-medium">
                        Ciclo Programado ({activePlan?.duration_weeks || 8} Semanas)
                      </span>
                    </div>
                    <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
                      {currentTrainingDay.day_name}
                    </h2>
                  </div>

                  {/* Resumo Métrico Integrado da Sessão */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
                    <div className="bg-zinc-950/80 border border-zinc-800/80 rounded-xl px-3 py-2">
                      <span className="text-[10px] uppercase font-semibold text-zinc-500 block">Movimentos</span>
                      <span className="text-sm font-bold font-mono text-white">
                        {currentTrainingDay.exercises.length} prescritos
                      </span>
                    </div>

                    <div className="bg-zinc-950/80 border border-zinc-800/80 rounded-xl px-3 py-2">
                      <span className="text-[10px] uppercase font-semibold text-zinc-500 block">Séries Totais</span>
                      <span className="text-sm font-bold font-mono text-white">
                        {currentTrainingDay.exercises.reduce((acc, e) => acc + (e.target_sets || 3), 0)} de trabalho
                      </span>
                    </div>

                    <div className="bg-zinc-950/80 border border-zinc-800/80 rounded-xl px-3 py-2">
                      <span className="text-[10px] uppercase font-semibold text-zinc-500 block">Duração Média</span>
                      <span className="text-sm font-bold font-mono text-white">
                        ~{Math.round(currentTrainingDay.exercises.length * 10 + 10)} min
                      </span>
                    </div>

                    <div className="bg-zinc-950/80 border border-zinc-800/80 rounded-xl px-3 py-2">
                      <span className="text-[10px] uppercase font-semibold text-zinc-500 block">Metodologia</span>
                      <span className="text-sm font-bold text-zinc-200 truncate">
                        Dupla Sobrecarga
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row lg:flex-col gap-3 shrink-0 lg:min-w-[220px]">
                  <button
                    type="button"
                    onClick={() => setActiveWorkoutDay(currentTrainingDay)}
                    className="flex items-center justify-center gap-2.5 px-8 py-4 rounded-2xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-sm transition-all cursor-pointer whitespace-nowrap active:scale-[0.98] shadow-lg"
                  >
                    <Play className="w-4 h-4 fill-zinc-950" /> INICIAR TREINO AGORA
                  </button>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setActiveTab('plans')}
                      className="flex-1 px-3 py-2.5 rounded-xl bg-zinc-800/80 hover:bg-zinc-700 text-xs font-medium text-zinc-300 hover:text-white transition-all text-center cursor-pointer border border-zinc-700/50"
                    >
                      Editar Ficha
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('analytics')}
                      className="flex-1 px-3 py-2.5 rounded-xl bg-zinc-800/80 hover:bg-zinc-700 text-xs font-medium text-zinc-300 hover:text-white transition-all text-center cursor-pointer border border-zinc-700/50"
                    >
                      Manequim
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* ROSTER DETALHADO DOS EXERCÍCIOS DE HOJE */}
            <div className="space-y-3">
              <div className="flex items-center justify-between px-1">
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">
                    Roster de Exercícios ({currentTrainingDay.exercises.length})
                  </h3>
                  <p className="text-xs text-zinc-400">
                    Siga a sequência de prescrição para máxima eficiência neuromuscular
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveTab('exercises')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs font-medium text-zinc-300 hover:text-white hover:border-zinc-700 transition-all cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> Adicionar Exercício
                </button>
              </div>

              {/* LISTA DE EXERCÍCIOS DO DIA COM CARTOES TÁTEIS */}
              <div className="grid grid-cols-1 gap-3">
                {currentTrainingDay.exercises.map((pe, idx) => {
                  const lastPerf = FitnessStorageService.getLastPerformanceForExercise(pe.exercise.id);
                  const lastBestSet = lastPerf && lastPerf.length > 0 ? lastPerf[0] : null;

                  return (
                    <div
                      key={pe.id || idx}
                      className="bg-zinc-900/90 border border-zinc-800 hover:border-zinc-700/80 rounded-2xl p-4 sm:p-5 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 group"
                    >
                      <div className="flex items-start sm:items-center gap-4 min-w-0">
                        {/* Índice Numérico Monospaçado */}
                        <span className="w-7 text-center font-mono font-bold text-sm text-zinc-500 shrink-0 mt-1 sm:mt-0">
                          {String(idx + 1).padStart(2, '0')}
                        </span>

                        {/* Miniatura do Exercício */}
                        <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0 border border-zinc-800 bg-zinc-950 relative">
                          <ExerciseVectorIllustration
                            exerciseId={pe.exercise.id}
                            exerciseName={pe.exercise.name}
                            targetMuscle={pe.exercise.target_muscle}
                            category={pe.exercise.category}
                            imageUrl={pe.exercise.thumbnail_url}
                            showBiomechanics={false}
                            className="w-full h-full object-cover"
                          />
                        </div>

                        {/* Detalhes do Exercício */}
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <h4 className="text-sm sm:text-base font-bold text-white tracking-tight truncate group-hover:text-zinc-100">
                              {pe.exercise.name}
                            </h4>
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-zinc-800 text-zinc-300 border border-zinc-700/60 uppercase shrink-0">
                              {MUSCLE_LABELS[pe.exercise.target_muscle as MuscleGroup]}
                            </span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-zinc-950 text-zinc-400 border border-zinc-800 capitalize shrink-0 hidden sm:inline-block">
                              {pe.exercise.category === 'barbell'
                                ? 'Barra Olímpica'
                                : pe.exercise.category === 'dumbbell'
                                ? 'Halteres'
                                : pe.exercise.category === 'machine'
                                ? 'Máquina'
                                : pe.exercise.category === 'cable'
                                ? 'Polia'
                                : 'Corporal'}
                            </span>
                          </div>

                          {/* Prescrição: Séries, Reps e Descanso */}
                          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-zinc-400 mt-1 font-mono">
                            <span className="text-white font-semibold">
                              {pe.target_sets} séries × {pe.min_reps}-{pe.max_reps} reps
                            </span>
                            <span>·</span>
                            <span>{pe.rest_seconds || 90}s descanso</span>
                          </div>

                          {/* Benchmark de Sobrecarga: Último Registro */}
                          {lastBestSet ? (
                            <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-300 mt-2 pt-2 border-t border-zinc-800/60 font-mono">
                              <span className="text-[10px] uppercase font-sans font-semibold tracking-wider text-zinc-500">
                                Anterior:
                              </span>
                              <span className="font-bold text-white bg-zinc-950 px-2 py-0.5 rounded border border-zinc-800">
                                {lastBestSet.weight_kg} kg × {lastBestSet.reps_performed} reps
                              </span>
                              {lastBestSet.rpe && (
                                <span className="text-zinc-400 text-[11px]">
                                  (RPE {lastBestSet.rpe})
                                </span>
                              )}
                              <span className="text-zinc-600 hidden sm:inline">·</span>
                              <span className="text-zinc-400 font-sans text-[11px] hidden sm:inline">
                                Meta: atingir {pe.max_reps} reps para subir +2kg
                              </span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-2 text-[11px] text-zinc-400 mt-2 pt-2 border-t border-zinc-800/60 font-sans">
                              <span className="text-[10px] uppercase font-semibold tracking-wider text-zinc-500">
                                Meta Inicial:
                              </span>
                              <span>Estabelecer baseline ({pe.min_reps}-{pe.max_reps} reps com 2 RIR)</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Ações Rápidas por Movimento */}
                      <div className="flex items-center gap-2 self-end md:self-center shrink-0 pt-2 md:pt-0">
                        <button
                          type="button"
                          onClick={() => setExecutingExercise(pe.exercise)}
                          className="px-3.5 py-2 rounded-xl bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 hover:text-white text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 border border-zinc-700/60"
                          title="Ver biomecânica e instruções"
                        >
                          <Info className="w-3.5 h-3.5 text-zinc-400" /> Biomecânica
                        </button>

                        <button
                          type="button"
                          onClick={() => setActiveWorkoutDay(currentTrainingDay)}
                          className="px-4 py-2 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs transition-all cursor-pointer whitespace-nowrap active:scale-95 shadow-sm flex items-center gap-1.5"
                        >
                          <Play className="w-3 h-3 fill-zinc-950" /> Treinar
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* CARD EXPLICATIVO: SISTEMA DE DUPLA SOBRECARGA & RPE */}
            <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-5 sm:p-6 flex items-start gap-4 shadow-sm">
              <div className="w-9 h-9 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-300 shrink-0 mt-0.5">
                <Sparkles className="w-4 h-4 text-zinc-300" />
              </div>
              <div className="text-xs text-zinc-400 leading-relaxed">
                <span className="font-bold text-white block text-sm mb-1">
                  Algoritmo Científico de Dupla Sobrecarga
                </span>
                Durante o treino, complete todas as séries no limite superior de repetições (ex: 8 no Levantamento Terra, 10 no Supino). Quando conseguir todas as séries na meta com boa técnica, o sistema recomendará aumentar o peso na próxima sessão (+2kg em membros superiores / +4kg em inferiores). Registre o RPE (1 a 10) para monitorar sua fadiga do sistema nervoso central.
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* ABA 2: BIO-FEEDBACK ANATÔMICO & TELEMETRIA                                 */}
        {/* ========================================================================= */}
        {activeTab === 'analytics' && (
          <div className="space-y-6 animate-fade-in">
            {/* Header da Seção de Bio-Feedback */}
            <div className="bg-zinc-900/90 border border-zinc-800 rounded-3xl p-6 sm:p-7 shadow-sm">
              <span className="text-[10px] uppercase font-bold tracking-wider text-zinc-400 block">
                Fisiologia & Recuperação
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1">
                Bio-Feedback Anatômico & Telemetria
              </h2>
              <p className="text-xs text-zinc-400 mt-1 max-w-2xl leading-relaxed">
                Acompanhe o volume cumulativo por grupamento muscular, consistência de treinos e curvas de progressão de carga estimada em 1RM.
              </p>
            </div>

            {/* GRID DO MANEQUIM + CONSISTÊNCIA & CARGAS */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Coluna 1: Manequim Digital Anatômico */}
              <div className="lg:col-span-5 flex flex-col gap-4">
                <DigitalMannequin
                  muscleScores={muscleScores}
                  selectedMuscle={selectedMuscle}
                  onSelectMuscle={(m) => setSelectedMuscle(m)}
                />
              </div>

              {/* Coluna 2: Consistência (Heatmap 12 Semanas) + Gráfico de Cargas */}
              <div className="lg:col-span-7 space-y-6">
                <ConsistencyHeatmap sessions={sessions} />
                <VolumeProgressionChart sessions={sessions} />
              </div>
            </div>

            {/* HALL DA FAMA: RECORDES PESSOAIS (PRs) */}
            <div className="bg-zinc-900/90 border border-zinc-800 rounded-3xl p-5 sm:p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-400 block">
                    Força Absoluta
                  </span>
                  <h3 className="text-base sm:text-lg font-bold text-white tracking-tight mt-0.5">
                    Hall da Fama de Recordes Pessoais (1RM)
                  </h3>
                </div>
                <span className="text-xs text-zinc-400 flex items-center gap-1.5 font-medium">
                  <Trophy className="w-3.5 h-3.5 text-zinc-300" /> Melhores Marcas
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {personalRecords.map((pr) => (
                  <div
                    key={pr.id}
                    className="bg-zinc-950 border border-zinc-800 hover:border-zinc-700/80 rounded-2xl p-4 transition-all"
                  >
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500 block truncate">
                      {pr.target}
                    </span>
                    <h4 className="text-sm font-bold text-white tracking-tight mt-1 truncate">
                      {pr.name}
                    </h4>
                    <div className="mt-3 flex items-baseline justify-between">
                      <div>
                        <span className="text-[10px] text-zinc-400 block font-medium">Melhor Carga</span>
                        <span className="font-mono font-extrabold text-lg text-white">
                          {pr.maxWeight} <span className="text-xs font-normal text-zinc-400">kg</span>
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-zinc-400 block font-medium">1RM Teórico</span>
                        <span className="font-mono font-bold text-sm text-zinc-200">
                          {pr.best1RM} kg
                        </span>
                      </div>
                    </div>
                    <div className="mt-2.5 pt-2.5 border-t border-zinc-800/80 flex items-center justify-between text-[11px] text-zinc-400">
                      <span>{pr.bestReps} reps registradas</span>
                      <span className="font-mono text-zinc-500">{pr.lastDate}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* ABA 2: FICHAS DE TREINO (WORKOUT PLAN MANAGER)                             */}
        {/* ========================================================================= */}
        {activeTab === 'plans' && (
          <div className="animate-fade-in">
            <WorkoutPlanManager
              plans={plans}
              onSavePlans={handleSavePlans}
              onStartWorkout={(day) => setActiveWorkoutDay(day)}
            />
          </div>
        )}

        {/* ========================================================================= */}
        {/* ABA 3: BIBLIOTECA DE EXERCÍCIOS                                            */}
        {/* ========================================================================= */}
        {activeTab === 'exercises' && (
          <div className="space-y-6">
            {/* Header da Biblioteca */}
            <div className="bg-zinc-900/80 border border-zinc-800 rounded-3xl p-5 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-zinc-800 border border-zinc-700/60 flex items-center justify-center text-zinc-200">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-white tracking-tight">
                      Biblioteca de Exercícios
                    </h2>
                    <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-300 border border-zinc-700/60">
                      {allExercises.length} Total
                    </span>
                  </div>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    Banco completo de exercícios com sobrecarga progressiva e biomecânica
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsCreateCustomOpen(true)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-medium text-xs transition-all cursor-pointer whitespace-nowrap"
              >
                <Plus className="w-4 h-4 text-zinc-300" /> Cadastrar Exercício
              </button>
            </div>

            {/* BARRA DE BUSCA + CHIPS RÁPIDOS */}
            <div className="space-y-3">
              <div className="relative">
                <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3" />
                <input
                  type="text"
                  placeholder="Buscar pelo nome do exercício (ex: terra, supino, agachamento, stiff, rosca)..."
                  value={exerciseCatalogSearch}
                  onChange={(e) => setExerciseCatalogSearch(e.target.value)}
                  className="w-full bg-zinc-900/90 border border-zinc-800 rounded-xl pl-10 pr-4 py-2.5 text-white text-xs focus:border-zinc-500 focus:outline-none placeholder:text-zinc-500"
                />
                {exerciseCatalogSearch && (
                  <button
                    type="button"
                    onClick={() => setExerciseCatalogSearch('')}
                    className="absolute right-3.5 top-2.5 text-zinc-500 hover:text-white text-xs cursor-pointer"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* FILTROS RÁPIDOS EM CHIPS */}
              <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
                {[
                  { id: 'all', label: `Todos (${allExercises.length})` },
                  { id: 'hypertrophy', label: 'Hipertrofia & Ciência' },
                  { id: 'deadlifts', label: 'Levantamento Terra & RDL' },
                  { id: 'chest', label: 'Peito' },
                  { id: 'back', label: 'Costas' },
                  { id: 'legs', label: 'Pernas' },
                  { id: 'shoulders', label: 'Ombros' },
                  { id: 'arms', label: 'Braços' },
                  { id: 'core', label: 'Abdômen' },
                ].map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setCatalogCategory(cat.id as QuickCategory)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                      catalogCategory === cat.id
                        ? 'bg-white text-zinc-950 font-semibold shadow-sm'
                        : 'bg-zinc-900/80 text-zinc-400 border border-zinc-800 hover:text-white hover:border-zinc-700'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>

              {/* Filtro por Equipamento */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
                <span className="text-[11px] font-medium text-zinc-500 shrink-0 mr-1">
                  Equipamento:
                </span>
                {[
                  { id: 'all', label: 'Todos' },
                  { id: 'barbell', label: 'Barra' },
                  { id: 'dumbbell', label: 'Halteres' },
                  { id: 'machine', label: 'Máquinas' },
                  { id: 'cable', label: 'Polia' },
                  { id: 'bodyweight', label: 'Corporal' },
                ].map((eq) => (
                  <button
                    key={eq.id}
                    type="button"
                    onClick={() => setExerciseCatalogEquipment(eq.id)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all cursor-pointer ${
                      exerciseCatalogEquipment === eq.id
                        ? 'bg-zinc-800 text-white font-semibold'
                        : 'text-zinc-500 hover:text-zinc-300'
                    }`}
                  >
                    {eq.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Contador de Resultados */}
            <div className="text-xs text-zinc-400 font-medium px-1">
              Exibindo <strong>{filteredExercises.length}</strong> exercícios encontrados
            </div>

            {/* GRID DE CARDS DE EXERCÍCIOS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredExercises.map((ex) => (
                <div
                  key={ex.id}
                  className="bg-zinc-900/60 border border-zinc-800 hover:border-zinc-700 rounded-2xl p-4 shadow-sm flex flex-col justify-between transition-all group"
                >
                  <div>
                    {/* Imagem / Ilustração */}
                    <div
                      onClick={() => setExecutingExercise(ex)}
                      className="relative h-44 rounded-xl overflow-hidden mb-3 border border-zinc-800/80 bg-zinc-950 cursor-pointer transition-all"
                      title="Clique para abrir e registrar repetições e peso"
                    >
                      <ExerciseVectorIllustration
                        exerciseId={ex.id}
                        exerciseName={ex.name}
                        targetMuscle={ex.target_muscle}
                        category={ex.category}
                        imageUrl={ex.thumbnail_url}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        showBiomechanics={false}
                      />
                      <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                        <span className="px-2 py-0.5 rounded-md bg-zinc-950/85 backdrop-blur-md text-[10px] font-medium text-zinc-200 border border-zinc-700/60">
                          {MUSCLE_LABELS[ex.target_muscle as MuscleGroup]}
                        </span>
                        <span className="px-2 py-0.5 rounded-md bg-zinc-950/85 backdrop-blur-md text-[10px] font-medium text-zinc-400 border border-zinc-800/80 capitalize">
                          {ex.category === 'barbell'
                            ? 'Barra'
                            : ex.category === 'dumbbell'
                            ? 'Halteres'
                            : ex.category === 'machine'
                            ? 'Máquina'
                            : ex.category === 'cable'
                            ? 'Cabo'
                            : 'Peso Corporal'}
                        </span>
                      </div>
                    </div>

                    <h3
                      onClick={() => setExecutingExercise(ex)}
                      className="text-sm sm:text-base font-semibold text-white group-hover:text-zinc-200 transition-colors leading-snug mb-1 cursor-pointer"
                    >
                      {ex.name}
                    </h3>

                    {ex.secondary_muscles && ex.secondary_muscles.length > 0 && (
                      <div className="flex items-center gap-1 text-[10px] text-zinc-500 mb-2">
                        <span>Sinergistas:</span>
                        <span className="text-zinc-400">
                          {ex.secondary_muscles
                            .map((sm) => MUSCLE_LABELS[sm as MuscleGroup] || sm)
                            .join(' · ')}
                        </span>
                      </div>
                    )}

                    {ex.instructions && ex.instructions[0] && (
                      <p className="text-[11px] text-zinc-400 line-clamp-2 leading-relaxed border-t border-zinc-800/80 pt-2">
                        {ex.instructions[0]}
                      </p>
                    )}
                  </div>

                  {/* Ações: Registrar Séries / Adicionar à ficha */}
                  <div className="pt-3 border-t border-zinc-800/80 mt-3 space-y-2">
                    <button
                      type="button"
                      onClick={() => setExecutingExercise(ex)}
                      className="w-full py-2.5 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-semibold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-[0.98] shadow-sm"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" /> Registrar Séries & Carga
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setExerciseToAddToPlan(ex);
                        setTargetPlanDayId(activePlan?.days[0]?.id || '');
                      }}
                      className="w-full py-2 rounded-xl bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 hover:text-white font-medium text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Adicionar à Ficha
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* MODAL: SELECIONAR QUAL DIA DA FICHA RECEBERÁ O EXERCÍCIO */}
            {exerciseToAddToPlan && (
              <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
                <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 max-w-sm w-full shadow-2xl animate-fade-in">
                  <h3 className="text-base font-bold text-white tracking-tight mb-1">
                    Adicionar à Ficha Ativa
                  </h3>
                  <div className="flex items-center gap-3 my-3 p-2.5 rounded-2xl bg-zinc-950 border border-zinc-800">
                    <div className="w-12 h-12 rounded-xl overflow-hidden shrink-0 border border-zinc-800 bg-zinc-900">
                      <ExerciseVectorIllustration
                        exerciseId={exerciseToAddToPlan.id}
                        exerciseName={exerciseToAddToPlan.name}
                        targetMuscle={exerciseToAddToPlan.target_muscle}
                        category={exerciseToAddToPlan.category}
                        showBiomechanics={false}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-white truncate">{exerciseToAddToPlan.name}</p>
                      <p className="text-[10px] text-zinc-400 font-medium">
                        {MUSCLE_LABELS[exerciseToAddToPlan.target_muscle as MuscleGroup]}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2 mb-5">
                    <label className="text-xs text-zinc-300 font-medium block mb-1">
                      Escolha a Divisão:
                    </label>
                    {activePlan?.days.map((day) => (
                      <label
                        key={day.id}
                        className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                          targetPlanDayId === day.id
                            ? 'bg-zinc-800 border-zinc-500 text-white font-medium'
                            : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white'
                        }`}
                      >
                        <span className="text-xs">{day.day_name}</span>
                        <input
                          type="radio"
                          name="target_day"
                          value={day.id}
                          checked={targetPlanDayId === day.id}
                          onChange={() => setTargetPlanDayId(day.id)}
                          className="accent-white"
                        />
                      </label>
                    ))}
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setExerciseToAddToPlan(null)}
                      className="flex-1 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-medium cursor-pointer"
                    >
                      Cancelar
                    </button>
                    <button
                      type="button"
                      onClick={handleConfirmAddExerciseToPlan}
                      className="flex-1 py-2.5 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 text-xs font-semibold shadow-sm cursor-pointer"
                    >
                      Confirmar
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* MODAL: CRIAR EXERCÍCIO PERSONALIZADO */}
            {isCreateCustomOpen && (
              <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
                <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 max-w-md w-full shadow-2xl animate-fade-in">
                  <h3 className="text-base font-bold text-white tracking-tight mb-1">
                    Cadastrar Exercício Personalizado
                  </h3>
                  <p className="text-xs text-zinc-400 mb-4">
                    Adicione qualquer movimento à base de dados do seu sistema de treino
                  </p>

                  <form onSubmit={handleCreateCustomExercise} className="space-y-3.5">
                    <div>
                      <label className="text-[11px] text-zinc-300 font-medium block mb-1">
                        Nome do Exercício *
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: Levantamento Terra no Smith Machine"
                        value={customExerciseForm.name}
                        onChange={(e) =>
                          setCustomExerciseForm({ ...customExerciseForm, name: e.target.value })
                        }
                        required
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-white text-xs focus:border-zinc-500 focus:outline-none placeholder:text-zinc-600"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[11px] text-zinc-300 font-medium block mb-1">
                          Músculo Principal *
                        </label>
                        <select
                          value={customExerciseForm.target_muscle}
                          onChange={(e) =>
                            setCustomExerciseForm({
                              ...customExerciseForm,
                              target_muscle: e.target.value as MuscleGroup,
                            })
                          }
                          className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2.5 text-white text-xs focus:border-zinc-500 focus:outline-none"
                        >
                          {(Object.keys(MUSCLE_LABELS) as MuscleGroup[]).map((m) => (
                            <option key={m} value={m}>
                              {MUSCLE_LABELS[m]}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-[11px] text-zinc-300 font-medium block mb-1">
                          Equipamento *
                        </label>
                        <select
                          value={customExerciseForm.category}
                          onChange={(e) =>
                            setCustomExerciseForm({
                              ...customExerciseForm,
                              category: e.target.value as Exercise['category'],
                            })
                          }
                          className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2.5 text-white text-xs focus:border-zinc-500 focus:outline-none"
                        >
                          <option value="barbell">Barra</option>
                          <option value="dumbbell">Halteres</option>
                          <option value="machine">Máquina</option>
                          <option value="cable">Cabos / Polia</option>
                          <option value="bodyweight">Peso Corporal</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="text-[11px] text-zinc-300 font-medium block mb-1">
                        Dicas de Execução (uma por linha)
                      </label>
                      <textarea
                        rows={3}
                        placeholder="Ex: Pés na largura dos ombros&#10;Manter coluna travada&#10;Puxar com as costas"
                        value={customExerciseForm.instructions}
                        onChange={(e) =>
                          setCustomExerciseForm({ ...customExerciseForm, instructions: e.target.value })
                        }
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-white text-xs focus:border-zinc-500 focus:outline-none resize-none placeholder:text-zinc-600"
                      />
                    </div>

                    <div className="flex gap-2.5 pt-3 border-t border-zinc-800">
                      <button
                        type="button"
                        onClick={() => setIsCreateCustomOpen(false)}
                        className="flex-1 py-2.5 rounded-xl bg-zinc-800 text-zinc-400 hover:text-white text-xs font-medium transition-colors"
                      >
                        Cancelar
                      </button>
                      <button
                        type="submit"
                        className="flex-1 py-2.5 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 text-xs font-semibold shadow-sm transition-all"
                      >
                        Salvar Exercício
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* ABA 4: AI COACH INTELIGENTE (GEMINI AI + MEDIDAS CORPORAIS)                */}
        {/* ========================================================================= */}
        {activeTab === 'coach' && (
          <div className="animate-fade-in">
            <AICoachPanel
              measurements={measurements}
              onAddMeasurement={handleAddMeasurement}
              sessions={sessions}
              activePlan={activePlan}
            />
          </div>
        )}
      </main>

      {/* MODAL DE EXECUÇÃO ATIVA DO TREINO COMPLETO */}
      {activeWorkoutDay && (
        <WorkoutLoggerModal
          planDay={activeWorkoutDay}
          isOpen={true}
          onClose={() => setActiveWorkoutDay(null)}
          onSessionCompleted={handleSessionCompleted}
        />
      )}

      {/* MODAL DE EXECUÇÃO / TESTE DE SÉRIES DE UM EXERCÍCIO INDIVIDUAL */}
      {executingExercise && (
        <ExerciseExecutionModal
          exercise={executingExercise}
          isOpen={true}
          onClose={() => setExecutingExercise(null)}
        />
      )}

      {/* MODAL DE CELEBRAÇÃO DE TREINO CONCLUÍDO - MINIMALISTA */}
      {completedCelebrationSession && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl text-center animate-fade-in">
            <div className="w-14 h-14 rounded-2xl bg-white text-zinc-950 flex items-center justify-center mx-auto mb-4 shadow-sm">
              <Trophy className="w-7 h-7 stroke-[2]" />
            </div>

            <span className="text-[10px] font-semibold uppercase tracking-widest text-zinc-400">
              Sessão Concluída
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-white mt-1">
              {completedCelebrationSession.plan_day_title}
            </h3>

            <div className="grid grid-cols-2 gap-3 my-5">
              <div className="bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800">
                <span className="text-[10px] text-zinc-400 block font-medium">Duração</span>
                <span className="text-base font-bold font-mono text-white">
                  {completedCelebrationSession.duration_minutes} min
                </span>
              </div>

              <div className="bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800">
                <span className="text-[10px] text-zinc-400 block font-medium">Volume Total</span>
                <span className="text-base font-bold font-mono text-white">
                  {calculateVolumeLoad(
                    Object.values(completedCelebrationSession.exercises_logs)
                      .flat()
                      .filter((s) => s.completed)
                  ).toLocaleString('pt-BR')}{' '}
                  kg
                </span>
              </div>
            </div>

            <p className="text-xs text-zinc-300 leading-relaxed mb-6">
              Suas cargas e repetições foram gravadas com sucesso. A progressão de carga e o mapa de bio-feedback foram atualizados para a sua próxima sessão!
            </p>

            <button
              type="button"
              onClick={() => setCompletedCelebrationSession(null)}
              className="w-full py-3.5 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-semibold text-xs shadow-sm transition-all cursor-pointer active:scale-95"
            >
              Continuar para o Painel
            </button>
          </div>
        </div>
      )}

      {/* MODAL DO SCHEMA SQL SUPABASE */}
      <DatabaseSchemaModal
        isOpen={isSchemaModalOpen}
        onClose={() => setIsSchemaModalOpen(false)}
      />

      {/* DOCK INFERIOR (BOTTOM NAVIGATION BAR - MINIMALISTA) */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#09090b]/95 backdrop-blur-xl border-t border-zinc-800/80 px-2 py-2">
        <div className="max-w-md mx-auto grid grid-cols-5 gap-1">
          <button
            type="button"
            onClick={() => setActiveTab('workout')}
            className={`flex flex-col items-center gap-1 py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'workout'
                ? 'text-white font-semibold'
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <Dumbbell className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="text-[10px] tracking-tight">Treino</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('analytics')}
            className={`flex flex-col items-center gap-1 py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'analytics'
                ? 'text-white font-semibold'
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <Activity className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="text-[10px] tracking-tight">Análise</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('plans')}
            className={`flex flex-col items-center gap-1 py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'plans'
                ? 'text-white font-semibold'
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <Layers className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="text-[10px] tracking-tight">Fichas</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('exercises')}
            className={`flex flex-col items-center gap-1 py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'exercises'
                ? 'text-white font-semibold'
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <BookOpen className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="text-[10px] tracking-tight">Exercícios</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('coach')}
            className={`flex flex-col items-center gap-1 py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'coach'
                ? 'text-white font-semibold'
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <Brain className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="text-[10px] tracking-tight">Coach</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
